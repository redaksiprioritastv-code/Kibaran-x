<div id="sidebar-category">
	<div class="sidebar-category-wrap">
		<?php if ( is_active_sidebar( 'sidebar-category' ) ) : ?>
		
			<?php dynamic_sidebar( 'sidebar-category' ); ?>
		
		<?php endif; ?>

</div></div><!-- AKHIR SIDEBAR CATEGORY -->