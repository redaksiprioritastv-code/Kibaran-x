var zx = jQuery.noConflict();
zx(".hamburger-button").click(function() {
    zx(".mobile-menu-kiri-wrap").slideToggle();
		zx('body').css('overflow', 'hidden');
}),zx(".close-button-hamburger").click(function() {
    zx(".mobile-menu-kiri-wrap").hide();
	zx('body').css('overflow', 'visible');
}), zx("#search-mobile-button").click(function() {
    zx("header #searchform").slideToggle()
}), zx(document).ready(function() {
    zx(".share-button-timeline").click(function(o) {
        o.stopPropagation(), zx(this).next(".share-popup").toggle()
    }), zx(".share-popup").on("click", function(o) {
        o.stopPropagation()
    })
})

// close mobile menu kiri wrap when click outside div
zx(document).mouseup(function(e) 
{
    var container = zx("div.mobile-menu-kiri-wrap");

    // if the target of the click isn't the container nor a descendant of the container
    if (!container.is(e.target) && container.has(e.target).length === 0) 
    {
        container.hide();
		zx('body').css('overflow', 'visible');
    }
});
	
	 /* zx(document).on("click", function() {
    zx(".share-popup").hide()
});
var prevScrollpos = window.pageYOffset;
window.onscroll = function() {
    var o = window.pageYOffset;
    document.getElementById("single-share-wrap-mobile").style.bottom = prevScrollpos > o ? "0" : "-200px", prevScrollpos = o
},  */
	
	/* zx(function() {
    zx(window).on("load", function() {
        zx("[data-src]").each(function() {
            var o = zx(this),
                n = zx(this).data("src");
            o.attr("src", n).css('filter', 'none'), console.log(n)
        })
    })
}); */
zx('#lightSlider').lightSlider({
    auto: true,
    item: 1,
    loop: true,
    slideMargin: 0,
    pause: 5000,
    keyPress: true,
    controls: true,
    prevHtml: '',
    nextHtml: '',
});

var clipboard = new ClipboardJS('.copas');

    clipboard.on('success', function(e) {
        console.log(e);
    });

    clipboard.on('error', function(e) {
        console.log(e);
    });

  zx(".owl-carousel").owlCarousel({
	    center: false,
    items:1,
    loop:false,
    margin:10,
	  stagePadding: 15
  });


  zx(".testowl").owlCarousel({
   center: false,
    items:10,
    loop:false,
    margin:10,
  });




if (zx(window).width() <= 460) {
    zx("#menu-utama-mobile > li.menu-item-has-children > a").click(function(){
        zx(this).find('ul.sub-menu').toggle();
    });
};

if (zx(window).width() <= 460) {
    zx(".mobile-menu-kiri > li.menu-item-has-children > a").click(function(){
        zx(this).find('ul.sub-menu').toggle();
		 zx(this).siblings().find("ul.sub-menu").hide();
    });
};






zx('.single-article-text').readingTime();



zx( "ul.mobile-menu-kiri li.menu-item-has-children:has(ul)" ).click(function(){ // When a li that has a ul is clicked ...
	zx(this).toggleClass('active'); // then toggle (add/remove) the class 'active' on it. 
});


const button = document.getElementById('geserkiri');

button.onclick = function () {
  document.getElementById('menu-utama').scrollLeft -= 200;
};

var haha = document.getElementById('geserkanan');

haha.onclick = function () {
  document.getElementById('menu-utama').scrollLeft += 200;
};

// script tab
/* zx(document).ready(function() {    

zx('#tabku li a:not(:first)').addClass('inactive');
zx('.container-content').hide();
zx('.container-content:first').show();
    
zx('#tabku li a').click(function(){
    var t = zx(this).attr('id');
  if(zx(this).hasClass('inactive')){ //this is the start of our condition 
    zx('#tabku li a').addClass('inactive');           
    zx(this).removeClass('inactive');
    
    zx('.container-content').hide();
    zx('#'+ t + 'C').fadeIn('slow');
 }
});

}); 


zx(document).ready(function(){
 zx('.container-content').hide();
zx('.container-content:first').show();
  zx('#tabku li a').click(function(){
    zx('li a').removeClass("active");
    zx(this).addClass("active");
	  zx('.container-content').hide();
    zx('#'+ t + 'C').fadeIn('slow');
});
});*/

zx('.tab-link').click( function() {
	
	var tabID = zx(this).attr('data-tab');
	
	zx(this).addClass('active').siblings().removeClass('active');
	
	zx('#tab-'+tabID).addClass('active').siblings().removeClass('active');
});


zx('iframe[src*="youtube"]').wrap("<div class='video-container'></div>");










// mobile dark mode switch


const toggleSwitch = document.querySelector('.tombolmodegelap');
const currentTheme = localStorage.getItem('theme');

if (currentTheme) {
    document.documentElement.setAttribute('data-theme', currentTheme);
  
    if (currentTheme === 'dark') {
        toggleSwitch.checked = true;
    }
}

function switchTheme(e) {
    if (e.target.checked) {
        document.documentElement.setAttribute('data-theme', 'dark');
        localStorage.setItem('theme', 'dark');
    }
    else {        document.documentElement.setAttribute('data-theme', 'light');
          localStorage.setItem('theme', 'light');
    }    
}

toggleSwitch.addEventListener('change', switchTheme, false);



// scroll to top
zx(document).ready(function() {
    var o = zx(".scrollTop");
    zx(window).scroll(function() {
        100 < zx(this).scrollTop() ? zx(o).css("opacity", "0.6") : zx(o).css("opacity", "0")
    }), zx(o).click(function() {
        return zx("html, body").animate({
            scrollTop: 0
        }, 800), !1
    });
    var l = zx("#h1").position(),
        t = zx("#h2").position(),
        i = zx("#h3").position();
    zx(".link1").click(function() {
        return zx("html, body").animate({
            scrollTop: l.top
        }, 500), !1
    }), zx(".link2").click(function() {
        return zx("html, body").animate({
            scrollTop: t.top
        }, 500), !1
    }), zx(".link3").click(function() {
        return zx("html, body").animate({
            scrollTop: i.top
        }, 500), !1
    })
});


zx('.marquee').marquee({
	//speed in milliseconds of the marquee
    duration: 25000,
	pauseOnHover: true,
	gap: 30,
	  //true or false - should the marquee be duplicated to show an effect of continues flow
    duplicated: true,
	startVisible: true
});

 /* zx('#imageGallery').lightSlider({
        gallery:true,
        item:1,
        loop:true,
        thumbItem:9,
        slideMargin:0,
        enableDrag: false,
        currentPagerPosition:'left',
        onSliderLoad: function(el) {
            el.lightGallery({
                selector: '#imageGallery .lslide'
            });
        }   
    });  */

//zx('#imageGallery').lightSlider({
//    gallery: true,
//    item: 1,
//    loop:true,
//    slideMargin: 0,
//    thumbItem: 6,
//	adaptiveHeight: true,
//	enableTouch:false,
//        enableDrag:false,
//	auto: true,
//	controls: false,
//	pager: true,
//	pause: 4000
//});

zx('#imageGallery').lightSlider({
    gallery: true,
    item: 1,
    loop: true,
    slideMargin: 0,
    thumbItem: 7,
    auto: true,
    controls: false,

            slideMargin: 0,

});

// ----------------------------------------------------
// Adding the placeholders in textfields of login form 
// ----------------------------------------------------


//jQuery(document).ready(function(zx) {

//	zx('#loginform input[type="text"]').attr('placeholder', 'Username');
//	zx('#loginform input[type="password"]').attr('placeholder', 'Password');
	
//	zx('#loginform label[for="user_login"]').contents().filter(function() {
//		return this.nodeType === 3;
//	}).remove();
//	zx('#loginform label[for="user_pass"]').contents().filter(function() {
//		return this.nodeType === 3;
//	}).remove();
	
//	zx('input[type="checkbox"]').click(function() {
//		zx(this+':checked').parent('label').css("background-position","0px -20px");
//		zx(this).not(':checked').parent('label').css("background-position","0px 0px");
//	});

//});


