<div id="sidebar-banner-bawah-block1">
		<?php if ( is_active_sidebar( 'sidebar-banner-bawah-block1' ) ) { ?>
		<div class="sidebar-banner-bawah-block1-wrap">
			<?php dynamic_sidebar( 'sidebar-banner-bawah-block1' ); ?>
		</div><!-- sidebar-bawah-block1 WRAP -->
		<?php } else { ?>
	<div>
			
		</div><!-- sidebar-bawah-block1 WRAP -->
<?php } ?>
</div><!-- sidebar-bawah-block1 BANNER -->