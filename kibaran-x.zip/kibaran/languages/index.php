<?php
/**
 * Keep silent gold.
 *
 * @package idtheme
 */
