<div id="sidebar-single">
	<div class="sidebar-single-wrap">
		<?php if ( is_active_sidebar( 'sidebar-single' ) ) : ?>
			<?php dynamic_sidebar( 'sidebar-single' ); ?>
		<?php endif; ?>
</div></div><!-- AKHIR SIDEBAR SINGLE -->