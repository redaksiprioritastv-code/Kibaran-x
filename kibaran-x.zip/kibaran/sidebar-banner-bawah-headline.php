<div id="sidebar-banner-bawah-headline">

		<?php if (get_theme_mod('adsbawahheadline')!="") {?> 

		<div class="sidebar-banner-bawah-headline-wrap">

			<?php echo get_theme_mod('adsbawahheadline'); ?>

		</div><!-- sidebar-bawah-headline WRAP -->

		<?php } else { ?>

	<div>

			

		</div><!-- sidebar-bawah-headline WRAP -->

<?php } ?>

</div><!-- sidebar-bawah-headline BANNER -->