<div id="sidebar-custom-homepage">
	<div class="sidebar-custom-homepage-wrap">
		<?php if ( is_active_sidebar( 'sidebar-custom-homepage' ) ) : ?>
		
			<?php dynamic_sidebar( 'sidebar-custom-homepage' ); ?>
		
		<?php endif; ?>

</div></div><!-- AKHIR SIDEBAR CUSTOM HOMEPAGE -->