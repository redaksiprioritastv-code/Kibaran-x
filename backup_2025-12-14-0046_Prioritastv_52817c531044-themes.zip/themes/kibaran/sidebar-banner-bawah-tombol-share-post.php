<div id="sidebar-banner-bawah-tombol-share-post">

		<?php if (get_theme_mod('adsbawahsharepost')!="") { ?>

		<div class="sidebar-banner-bawah-tombol-share-post-wrap">

			<?php echo get_theme_mod('adsbawahsharepost'); ?>

		</div><!-- sidebar-bawah-tombol-share-post WRAP -->

		<?php } else { ?>

	<div>

			

		</div><!-- sidebar-bawah-tombol-share-post WRAP -->

<?php } ?>

</div><!-- sidebar-bawah-tombol-share-post BANNER -->