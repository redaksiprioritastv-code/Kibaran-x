<div id="after-post-banner">
		<?php if ( is_active_sidebar( 'after-post-banner' ) ) : ?>
		<div class="after-post-banner-wrap">
			<?php dynamic_sidebar( 'after-post-banner' ); ?>
		</div><!--AFTER POST BANNER WRAP -->
		<?php endif; ?>
</div><!-- AKHIR AFTER POST BANNER -->