<div id="post-banner">
		<?php if ( is_active_sidebar( 'post-banner' ) ) : ?>
		<div class="post-banner-wrap">
			<?php dynamic_sidebar( 'post-banner' ); ?>
		</div><!-- POST BANNER WRAP -->
		<?php endif; ?>
</div><!-- AKHIR POST BANNER -->