				<?php 
		if (get_theme_mod('adsbawahheader')!="") {?> 
<div id="sidebar-header">
		<div class="sidebar-header-wrap">
			<?php echo get_theme_mod('adsbawahheader'); ?>
		</div><!-- sidebar-header-wrap -->
</div><!-- akhir sidebar-header -->
		<?php } else { ?>
	
<?php } ?>
