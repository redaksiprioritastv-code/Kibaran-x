<?php 
/***** RECENT POST WIDGET *****/

add_action( 'widgets_init', 'rpjc_register_widget_cat_recent_posts' );

function rpjc_register_widget_cat_recent_posts() {

    register_widget( 'rpjc_widget_cat_recent_posts' );

}

class rpjc_widget_cat_recent_posts extends WP_Widget {

    public function __construct() {
    
        parent::__construct(
    
            'rpjc_widget_cat_recent_posts',
            __( 'Recent Posts by Category', 'recent-posts-by-category-widget' ),
            array(
                'classname'   => 'rpjc_widget_cat_recent_posts widget_recent_entries',
                'description' => __( 'Display recent blog posts from a specific category', 'recent-posts-by-category-widget' )
            )
    
        );
    
    }

    // Build the widget settings form

    function form( $instance ) {
    
        $defaults  = array( 'title' => '', 'category' => '', 'number' => 5, 'show_date' => '' );
        $instance  = wp_parse_args( ( array ) $instance, $defaults );
        $title     = $instance['title'];
        $category  = $instance['category'];
        $number    = $instance['number'];

        
        ?>
        
        <p>
            <label for="rpjc_widget_cat_recent_posts_title"><?php _e( 'Title' ); ?>:</label>
            <input type="text" class="widefat" id="rpjc_widget_cat_recent_posts_title" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo esc_attr( $title ); ?>" />
        </p>
        
        <p>
            <label for="rpjc_widget_cat_recent_posts_category"><?php _e( 'Category' ); ?>:</label>              
            
            <?php

            wp_dropdown_categories( array(

                'orderby'    => 'title',
                'hide_empty' => false,
                'name'       => $this->get_field_name( 'category' ),
                'id'         => 'rpjc_widget_cat_recent_posts_category',
                'class'      => 'widefat',
                'selected'   => $category

            ) );

            ?>

        </p>
        
        <p>
            <label for="rpjc_widget_cat_recent_posts_number"><?php _e( 'Number of posts to show' ); ?>: </label>
            <input type="text" id="rpjc_widget_cat_recent_posts_number" name="<?php echo $this->get_field_name( 'number' ); ?>" value="<?php echo esc_attr( $number ); ?>" size="3" />
        </p>

    
        <?php
    
    }

    // Save widget settings

    function update( $new_instance, $old_instance ) {

        $instance              = $old_instance;
        $instance['title']     = wp_strip_all_tags( $new_instance['title'] );
        $instance['category']  = wp_strip_all_tags( $new_instance['category'] );
        $instance['number']    = is_numeric( $new_instance['number'] ) ? intval( $new_instance['number'] ) : 5;
    

        return $instance;

    }

    // Display widget

    function widget( $args, $instance ) {

        extract( $args );

        echo $before_widget;

        $title     = apply_filters( 'widget_title', $instance['title'], $instance, $this->id_base );
        $category  = $instance['category'];
        $number    = $instance['number'];
    

        if ( !empty( $title ) ) echo $before_title . $title . $after_title;

        $cat_recent_posts = new WP_Query( array( 

            'post_type'      => 'post',
            'posts_per_page' => $number,
            'cat'            => $category

        ) );

        if ( $cat_recent_posts->have_posts() ) {

            echo '<div class="text-wrap">';

            while ( $cat_recent_posts->have_posts() ) {

                $cat_recent_posts->the_post();
                echo '<div class="recent-post-widget">';
                if (has_post_thumbnail()) {
                the_post_thumbnail('foto-samping-kecil');
                    } else {
                      
    if ( has_post_format('video') ) {
        $youtubeUrl = get_post_meta(get_the_ID(), '_embed', true);
  echo '<img width="113" height="85" src="https://img.youtube.com/vi/'.$youtubeUrl.'/sddefault.jpg" alt="youtube thumbnail" />';
};
                }
                echo '<a href="' . get_permalink() . '">' . get_the_title() . '</a>';
                echo '<p class="waktu">' . get_the_time( get_option( 'date_format') ) .' | ' .get_the_time( get_option( 'time_format') ) . ' WIB </p><div class="clr"></div></div>';
                

            }

            echo '</div>';

        } else {

            _e( 'No posts yet.', 'recent-posts-by-category-widget' );

        }

        wp_reset_postdata();

        echo $after_widget;

    }

}

?>