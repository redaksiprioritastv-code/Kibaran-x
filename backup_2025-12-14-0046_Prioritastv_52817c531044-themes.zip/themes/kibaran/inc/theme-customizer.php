<?php 

// add text box in customizer

add_action( 'customize_register', 'kibaran_customizer' );


function kibaran_customizer( $wp_customize ) {
    

    /* CUSTOM LOGIN PAGE */
    $wp_customize->add_section( 'custompage' , array(
      'title'      => __('Custom Login Page', 'kibaran'), 
      'panel' => 'depan_id',
      'priority'   => 1,
      'description'=> __('The "wp-admin" login page will be redirected to the URL page you chose automatically', 'kibaran'),
    ));
    $wp_customize->add_setting( 'active-custompagelogin' , array(
      'default'    => 0,
      'transport'  => 'refresh'
    ));
    $wp_customize->add_control('active-custompagelogin' , array(
      'section' => 'custompage',
      'label' =>__('Enable Custom Login Page', 'kibaran'),
      'type'=> 'checkbox',
    ));
    if ( ! class_exists( 'WPSE_406789_Walker_Page_Options' ) ) {
        class WPSE_406789_Walker_Page_Options extends Walker_Page {
            public $choices = [];

            public function start_el( &$output, $data_object, $depth = 0, $args = [], $current_object_id = 0 ) {
                $pad = str_repeat( '&nbsp;', $depth * 3 );

                $this->choices[ $data_object->ID ] = $pad . get_the_title( $data_object );
            }
        }
    }

    $walker = new WPSE_406789_Walker_Page_Options();

    $pages = get_pages([
        'post_status' => [
            'publish',
            'private',
        ],
    ]);

    $walker->walk( $pages, 0, [], 0 );
    $wp_customize->add_setting('custompagelogin', array(
        'default'        => '',
    ));
    $wp_customize->add_control( 'custompagelogin', [
        'type' => 'select',
        'choices' => $walker->choices,
        'section' => 'custompage',
        'label' => __('Custom Login Page', 'kibaran'),
        'description' => __('Select the page as the login page', 'kibaran'),
    ]);

/* HEADLINE & BREAKING NEWS*/   
  $wp_customize->add_section( 'headline-breaking-section' , array(
    'title'      => __( 'Headline & Breaking News', 'kibaran' ),
    'priority'   => 2,
    'panel'             => 'depan_id',
     'description'=> __('Select the post tag that will be "Headline" and "Breaking News"', 'kibaran'),
) );

    $wp_customize->add_setting( 'active-headline' , array(
      'default'    => 0,
      'transport'  => 'refresh'
    ));
    $wp_customize->add_control('active-headline' , array(
      'section' => 'headline-breaking-section',
      'label' => __('Enable "Headline" on the homepage (Desktop)', 'kibaran'),
      'type'=> 'checkbox',
    ));
    $wp_customize->add_setting( 'active-headline-mobile' , array(
      'default'    => 0,
      'transport'  => 'refresh'
    ));
    $wp_customize->add_control('active-headline-mobile' , array(
      'section' => 'headline-breaking-section',
      'label' => __('Enable "Headline" on the homepage (Mobile)', 'kibaran'),
      'type'=> 'checkbox',
    ));

    $wp_customize->add_setting( 'active-headline-category' , array(
      'default'    => 0,
      'transport'  => 'refresh'
    ));
    $wp_customize->add_control('active-headline-category' , array(
      'section' => 'headline-breaking-section',
      'label' => __('Enable "Headline" on the category page (Desktop)', 'kibaran'),
      'type'=> 'checkbox',
    ));
    $wp_customize->add_setting( 'active-headline-category-mobile' , array(
      'default'    => 0,
      'transport'  => 'refresh'
    ));
    $wp_customize->add_control('active-headline-category-mobile' , array(
      'section' => 'headline-breaking-section',
      'label' => __('Enable "Headline" on the category page (Mobile)', 'kibaran'),
      'type'=> 'checkbox',
    ));

    $wp_customize->add_setting( 'active-headline-tag' , array(
      'default'    => 0,
      'transport'  => 'refresh'
    ));
    $wp_customize->add_control('active-headline-tag' , array(
      'section' => 'headline-breaking-section',
      'label' => __('Enable "Headline" on tag page (Desktop)', 'kibaran'),
      'type'=> 'checkbox',
    ));
    $wp_customize->add_setting( 'active-headline-tag-mobile' , array(
      'default'    => 0,
      'transport'  => 'refresh'
    ));
    $wp_customize->add_control('active-headline-tag-mobile' , array(
      'section' => 'headline-breaking-section',
      'label' => __('Enable "Headline" on tag page (Mobile)', 'kibaran'),
      'type'=> 'checkbox',
    ));
    $wp_customize->add_setting( 'active-sidebar-headline' , array(
      'default'    => 0,
      'transport'  => 'refresh'
    ));
    $wp_customize->add_control('active-sidebar-headline' , array(
      'section' => 'headline-breaking-section',
      'label' => __('Change "Popular Post" at right of "Headline" to Widget Sidebar Headline', 'kibaran'),
      'type'=> 'checkbox',
    ));
    $wp_customize->add_setting( 'deactive-sidebar-headline' , array(
      'default'    => 0,
      'transport'  => 'refresh'
    ));
    $wp_customize->add_control('deactive-sidebar-headline' , array(
      'section' => 'headline-breaking-section',
      'label' => __('Hide "Popular Post" at right of "Headline" or Widget Sidebar Headline in Mobile', 'kibaran'),
      'type'=> 'checkbox',
    ));

    require_once(TEMPLATEPATH . '/inc/class/class-customizer-library-tag.php');
    require_once(TEMPLATEPATH . '/inc/class/class-customizer-library-categories.php');
    $wp_customize->add_setting('headlinesetting', array(
      'default' => get_option('default_category', ''),
    ));

    $wp_customize->add_control(new Customizer_Library_Tag($wp_customize, 'headlinesetting', array(
        'label' => __('Headline Setting', 'kibaran'),
        
        'section' => 'headline-breaking-section',
        'settings' => 'headlinesetting',
        'args' => array(),
    )));

    $wp_customize->add_setting( 'headline-setting-basedon-latestpost' , array(
      'default'    => 0,
      'transport'  => 'refresh'
    ));
    $wp_customize->add_control('headline-setting-basedon-latestpost' , array(
      'section' => 'headline-breaking-section',
      'label' => __('Headlines based on latest posts', 'kibaran'),
      'type'=> 'checkbox',
    ));
    $wp_customize->add_setting( 'disable-headline-setting' , array(
      'default'    => 0,
      'transport'  => 'refresh'
    ));
    $wp_customize->add_control('disable-headline-setting' , array(
      'section' => 'headline-breaking-section',
      'label' => __('Headlines on category pages and tags based on latest posts from that page (you must uncheck previous settings)', 'kibaran'),
      'type'=> 'checkbox',
    ));


    // Create settings Headline Mobile
    $wp_customize->add_setting( 'headlinemobile' , array(
      'sanitize_callback' => 'wp_filter_nohtml_kses', //removes all HTML from content
      'type'          => 'theme_mod',
      'transport'     => 'refresh',
    ) );


    // Create control Headline Mobile
    $wp_customize->add_control( 'headlinemobile', array(
      'label'      => __('Mobile Headline Design', 'kibaran'),
      'section'    => 'headline-breaking-section',
      'settings'   => 'headlinemobile',
      'type'       => 'radio',
            'choices'    => array( 
              'model1' => 'Model 1',
              'model2' => 'Model 2',
            ),
    ) );

    $wp_customize->add_setting( 'textpopularposts' , array(
      'default'    => '',
      'transport'  =>  'refresh'
    ));
    $wp_customize->add_control('textpopularposts' , array(
      'section' => 'headline-breaking-section',
      'label' => __('Replacement for "Popular Posts" Text on the right side Headline.', 'kibaran'),
      'type'=>'text',
    ));

    $wp_customize->add_setting( 'active-breakingnews' , array(
      'default'    => 0,
      'transport'  => 'refresh'
    ));
    $wp_customize->add_control('active-breakingnews' , array(
      'section' => 'headline-breaking-section',
      'label' => __('Enable "Breaking News" on Homepage', 'kibaran'),
      'type'=> 'checkbox',
    ));

    $wp_customize->add_setting('breakingnewssetting', array(
        'default'        => '',
    ));

    $wp_customize->add_control(new Customizer_Library_Tag($wp_customize, 'breakingnewssetting', array(
        'label' => __('Breaking News Setting', 'kibaran'),
        'description' => 'Pilih Kategori untuk Breaking News',
        'section' => 'headline-breaking-section',
        'settings' => 'breakingnewssetting',
        'args' => array(),
    )));


/* SOSMED*/  
    $wp_customize->add_section( 'kibaran-section' , array(
    'title'      => __( 'Social media', 'kibaran' ),
    'priority'   => 3,
    'panel'             => 'depan_id'
) );

// add setting facebook
    $wp_customize->add_setting( 'facebook-id', array(
  'capability' => 'edit_theme_options',
  'default' => 'https://facebook.com/',
  'sanitize_callback' => 'sanitize_text_field',
) );

// add control facebook
$wp_customize->add_control( 'facebook-id', array(
  'type' => 'text',
  'section' => 'kibaran-section', 
  'label' => __( 'URL Facebook', 'kibaran'  )
) );
    
// add setting twitter
$wp_customize->add_setting( 'twitter-id', array(
  'capability' => 'edit_theme_options',
  'default' => 'https://twitter.com',
  'sanitize_callback' => 'sanitize_text_field',
) );

// add control twitter
$wp_customize->add_control( 'twitter-id', array(
  'type' => 'text',
  'section' => 'kibaran-section', 
  'label' => __( 'URL Twitter', 'kibaran'  )
) );
    
// add setting instagram
$wp_customize->add_setting( 'instagram-id', array(
  'capability' => 'edit_theme_options',
  'default' => 'https://instagram.com',
  'sanitize_callback' => 'sanitize_text_field',
) );

// add control instagram
$wp_customize->add_control( 'instagram-id', array(
  'type' => 'text',
  'section' => 'kibaran-section', 
  'label' => __( 'URL Instagram', 'kibaran'  )
) );
    
// add setting youtube
$wp_customize->add_setting( 'youtube-id', array(
  'capability' => 'edit_theme_options',
  'default' => 'https://youtube.com',
  'sanitize_callback' => 'sanitize_text_field',
) );

// add control youtube
$wp_customize->add_control( 'youtube-id', array(
  'type' => 'text',
  'section' => 'kibaran-section', 
  'label' => __( 'URL Youtube', 'kibaran'  )
) );
    
// add setting tiktok
$wp_customize->add_setting( 'tiktok-id', array(
  'capability' => 'edit_theme_options',
  'default' => 'https://tiktok.com',
  'sanitize_callback' => 'sanitize_text_field',
) );

// add control tiktok
$wp_customize->add_control( 'tiktok-id', array(
  'type' => 'text',
  'section' => 'kibaran-section', 
  'label' => __( 'URL Tiktok', 'kibaran'  )
) );
    
    
// Create panel Halaman Depan

$wp_customize->add_panel( 'depan_id', array(
    'title'          => __('Kibaran Setting', 'kibaran'),
    'priority'       => 20,
) );


// Pengaturan Header
$wp_customize->add_section( 'header_id' , array(
    'title'             => 'Header',
    'panel'             => 'depan_id',
    'priority' => 4,
) );
    
    $wp_customize->add_setting( 'sticky-header' , array(
      'default'    => 1,
      'transport'  => 'refresh'
    ));
    $wp_customize->add_control('sticky-header' , array(
      'section' => 'header_id',
      'label' => __('Enable Sticky on Header', 'kibaran'),
      'type'=> 'checkbox',
    ));



/** HOMEPAGE 1 **/

$wp_customize->add_section( 'block_id' , array(
    'title'             => __('Homepage', 'kibaran'),
    'panel'             => 'depan_id',
    'priority' => 4,
  'description' => __('<b>Note:</b> The "Block" setting will be active only for the "Block Category" homepage display option. Blocks 3, 5, 7, 9, 11, .. 29 are horizontal on the desktop display. If you want to deactivate the block, please change the Block option to "Select".', 'kibaran'),
) );
// Create settings jumlah pembaca
$wp_customize->add_setting( 'hidesidebarhomepage' , array(
    'type'          => 'theme_mod',
    'transport'     => 'refresh',
    'default'       => 0,
) );


// Create control Jumlah Pembaca
$wp_customize->add_control( 'hidesidebarhomepage', array(
    'label'      => __('Hide Sidebar on Homepage (normal Homepage Type) when accessed via mobile','kibaran'),
    'section'    => 'block_id',
    'type'       => 'checkbox',
    'default'       => 0,
) ); 

$wp_customize->add_setting( 'hidelatesttopics' , array(
    'type'          => 'theme_mod',
    'transport'     => 'refresh',
    'default'       => 0,
) );


// Create control Jumlah Pembaca
$wp_customize->add_control( 'hidelatesttopics', array(
    'label'      => __('Hide Latest Topics on Homepage when accessed via mobile','kibaran'),
    'section'    => 'block_id',
    'type'       => 'checkbox',
    'default'       => 0,
) ); 

// Pilihan Homepage
$wp_customize->add_setting( 'modelhomepage' , array(
    'sanitize_callback' => 'wp_filter_nohtml_kses', //removes all HTML from content
    'type'          => 'theme_mod',
    'transport'     => 'refresh',
    'default'       => 2,
) );


// Create control Arrow Menu Button
$wp_customize->add_control( 'modelhomepage', array(
    'label'      => __('Select Homepage Type', 'kibaran'),
    'section'    => 'block_id',
    'settings'   => 'modelhomepage',
    'type'       => 'radio',
        'choices'    => array( 
          '1' => __('Normal', 'kibaran'),
          '2' => __('Category Block', 'kibaran'),
        ),
) );


// add setting block1
    $wp_customize->add_setting('block1', array(
        'default'        => '',

    ));

    $wp_customize->add_control(new Customizer_Library_Categories($wp_customize, 'block1', array(
        'label' => 'Block 1',
        'section' => 'block_id',
        'settings' => 'block1',
        'args' => array(),
    )));
    
// add setting block2
    $wp_customize->add_setting('block2', array(
        'default'        => '',
    ));

    $wp_customize->add_control(new Customizer_Library_Categories($wp_customize, 'block2', array(
        'label' => 'Block 2',
        'section' => 'block_id',
        'settings' => 'block2',
        'args' => array(),
    )));
    
// add setting block3
    $wp_customize->add_setting('block3', array(
        'default'        => '',
    ));

    $wp_customize->add_control(new Customizer_Library_Categories($wp_customize, 'block3', array(
        'label' => 'Block 3',
        'section' => 'block_id',
        'settings' => 'block3',
        'args' => array(),
    )));
    
// add setting block4
    $wp_customize->add_setting('block4', array(
        'default'        => '',
    ));

    $wp_customize->add_control(new Customizer_Library_Categories($wp_customize, 'block4', array(
        'label' => 'Block 4',
        'section' => 'block_id',
        'settings' => 'block4',
        'args' => array(),
    )));
    
// add setting block5
    $wp_customize->add_setting('block5', array(
        'default'        => '',
    ));

    $wp_customize->add_control(new Customizer_Library_Categories($wp_customize, 'block5', array(
        'label' => 'Block 5',
        'section' => 'block_id',
        'settings' => 'block5',
        'args' => array(),
    )));
// add setting block6
    $wp_customize->add_setting('block6', array(
        'default'        => '',
    ));

    $wp_customize->add_control(new Customizer_Library_Categories($wp_customize, 'block6', array(
        'label' => 'Block 6',
        'section' => 'block_id',
        'settings' => 'block6',
        'args' => array(),
    )));
    
// add setting block7
    $wp_customize->add_setting('block7', array(
        'default'        => '',
    ));

    $wp_customize->add_control(new Customizer_Library_Categories($wp_customize, 'block7', array(
        'label' => 'Block 7',
        'section' => 'block_id',
        'settings' => 'block7',
        'args' => array(),
    )));

// add setting block8
    $wp_customize->add_setting('block8', array(
        'default'        => '',
    ));

    $wp_customize->add_control(new Customizer_Library_Categories($wp_customize, 'block8', array(
        'label' => 'Block 8',
        'section' => 'block_id',
        'settings' => 'block8',
        'args' => array(),
    )));

// add setting block9
    $wp_customize->add_setting('block9', array(
        'default'        => '',
    ));

    $wp_customize->add_control(new Customizer_Library_Categories($wp_customize, 'block9', array(
        'label' => 'Block 9',
        'section' => 'block_id',
        'settings' => 'block9',
        'args' => array(),
    )));

// add setting block10
    $wp_customize->add_setting('block10', array(
        'default'        => '',
    ));

    $wp_customize->add_control(new Customizer_Library_Categories($wp_customize, 'block10', array(
        'label' => 'Block 10',
        'section' => 'block_id',
        'settings' => 'block10',
        'args' => array(),
    )));

// add setting block11
    $wp_customize->add_setting('block11', array(
        'default'        => '',
    ));

    $wp_customize->add_control(new Customizer_Library_Categories($wp_customize, 'block11', array(
        'label' => 'Block 11',
        'section' => 'block_id',
        'settings' => 'block11',
        'args' => array(),
    )));
    
// add setting block12
    $wp_customize->add_setting('block12', array(
        'default'        => '',
    ));

    $wp_customize->add_control(new Customizer_Library_Categories($wp_customize, 'block12', array(
        'label' => 'Block 12',
        'section' => 'block_id',
        'settings' => 'block12',
        'args' => array(),
    )));
    
// add setting block13
    $wp_customize->add_setting('block13', array(
        'default'        => '',
    ));

    $wp_customize->add_control(new Customizer_Library_Categories($wp_customize, 'block13', array(
        'label' => 'Block 13',
        'section' => 'block_id',
        'settings' => 'block13',
        'args' => array(),
    )));
    
// add setting block14
    $wp_customize->add_setting('block14', array(
        'default'        => '',
    ));

    $wp_customize->add_control(new Customizer_Library_Categories($wp_customize, 'block14', array(
        'label' => 'Block 14',
        'section' => 'block_id',
        'settings' => 'block14',
        'args' => array(),
    )));
    
// add setting block15
    $wp_customize->add_setting('block15', array(
        'default'        => '',
    ));

    $wp_customize->add_control(new Customizer_Library_Categories($wp_customize, 'block15', array(
        'label' => 'Block 15',
        'section' => 'block_id',
        'settings' => 'block15',
        'args' => array(),
    )));
    
// add setting block16
    $wp_customize->add_setting('block16', array(
        'default'        => '',
    ));

    $wp_customize->add_control(new Customizer_Library_Categories($wp_customize, 'block16', array(
        'label' => 'Block 16',
        'section' => 'block_id',
        'settings' => 'block16',
        'args' => array(),
    )));
    
// add setting block17
    $wp_customize->add_setting('block17', array(
        'default'        => '',
    ));

    $wp_customize->add_control(new Customizer_Library_Categories($wp_customize, 'block17', array(
        'label' => 'Block 17',
        'section' => 'block_id',
        'settings' => 'block17',
        'args' => array(),
    )));
    
// add setting block18
    $wp_customize->add_setting('block18', array(
        'default'        => '',
    ));

    $wp_customize->add_control(new Customizer_Library_Categories($wp_customize, 'block18', array(
        'label' => 'Block 18',
        'section' => 'block_id',
        'settings' => 'block18',
        'args' => array(),
    )));
    
// add setting block19
    $wp_customize->add_setting('block19', array(
        'default'        => '',
    ));

    $wp_customize->add_control(new Customizer_Library_Categories($wp_customize, 'block19', array(
        'label' => 'Block 19',
        'section' => 'block_id',
        'settings' => 'block19',
        'args' => array(),
    )));
    
// add setting block20
    $wp_customize->add_setting('block20', array(
        'default'        => '',
    ));

    $wp_customize->add_control(new Customizer_Library_Categories($wp_customize, 'block20', array(
        'label' => 'Block 20',
        'section' => 'block_id',
        'settings' => 'block20',
        'args' => array(),
    )));
    
// add setting block21
    $wp_customize->add_setting('block21', array(
        'default'        => '',
    ));

    $wp_customize->add_control(new Customizer_Library_Categories($wp_customize, 'block21', array(
        'label' => 'Block 21',
        'section' => 'block_id',
        'settings' => 'block21',
        'args' => array(),
    )));
    
// add setting block22
    $wp_customize->add_setting('block22', array(
        'default'        => '',
    ));

    $wp_customize->add_control(new Customizer_Library_Categories($wp_customize, 'block22', array(
        'label' => 'Block 22',
        'section' => 'block_id',
        'settings' => 'block22',
        'args' => array(),
    )));
    
// add setting block23
    $wp_customize->add_setting('block23', array(
        'default'        => '',
    ));

    $wp_customize->add_control(new Customizer_Library_Categories($wp_customize, 'block23', array(
        'label' => 'Block 23',
        'section' => 'block_id',
        'settings' => 'block23',
        'args' => array(),
    )));
    
// add setting block24
    $wp_customize->add_setting('block24', array(
        'default'        => '',
    ));

    $wp_customize->add_control(new Customizer_Library_Categories($wp_customize, 'block24', array(
        'label' => 'Block 24',
        'section' => 'block_id',
        'settings' => 'block24',
        'args' => array(),
    )));
    
// add setting block25
    $wp_customize->add_setting('block25', array(
        'default'        => '',
    ));

    $wp_customize->add_control(new Customizer_Library_Categories($wp_customize, 'block25', array(
        'label' => 'Block 25',
        'section' => 'block_id',
        'settings' => 'block25',
        'args' => array(),
    )));
    
// add setting block26
    $wp_customize->add_setting('block26', array(
        'default'        => '',
    ));

    $wp_customize->add_control(new Customizer_Library_Categories($wp_customize, 'block26', array(
        'label' => 'Block 26',
        'section' => 'block_id',
        'settings' => 'block26',
        'args' => array(),
    )));
    
// add setting block27
    $wp_customize->add_setting('block27', array(
        'default'        => '',
    ));

    $wp_customize->add_control(new Customizer_Library_Categories($wp_customize, 'block27', array(
        'label' => 'Block 27',
        'section' => 'block_id',
        'settings' => 'block27',
        'args' => array(),
    )));
    
// add setting block28
    $wp_customize->add_setting('block28', array(
        'default'        => '',
    ));

    $wp_customize->add_control(new Customizer_Library_Categories($wp_customize, 'block28', array(
        'label' => 'Block 28',
        'section' => 'block_id',
        'settings' => 'block28',
        'args' => array(),
    )));
    
// add setting block29
    $wp_customize->add_setting('block29', array(
        'default'        => '',
    ));

    $wp_customize->add_control(new Customizer_Library_Categories($wp_customize, 'block29', array(
        'label' => 'Block 29',
        'section' => 'block_id',
        'settings' => 'block29',
        'args' => array(),
    )));
    
// add setting block30
    $wp_customize->add_setting('block30', array(
        'default'        => '',
    ));

    $wp_customize->add_control(new Customizer_Library_Categories($wp_customize, 'block30', array(
        'label' => 'Block 30',
        'section' => 'block_id',
        'settings' => 'block30',
        'args' => array(),
    )));
    
    
// Sanitize text
    function sanitize_text( $text ) {
        return sanitize_text_field( $text );
    }
    
// Create our panels

/* $wp_customize->add_panel( 'depan_id', array(
    'title'          => 'Halaman Depan',
) ); */
    
// add section Homepage
/* $wp_customize->add_section( 'homepage', 
 array(
    'title'       => __( 'Homepage', 'kibaran' ), 
    'priority'    => 20,
    'capability'  => 'edit_theme_options', 
 ) 
); */
    
/** HOMEPAGE 2 **/

$wp_customize->add_section( 'block_id2' , array(
    'title'             => __('Other Settings', 'kibaran'),
    'panel'             => 'depan_id',
    'priority' => 8,
  'priority' => 100,
) );
    $wp_customize->add_setting( 'texttopikterkini' , array(
      'default'    => '',
      'transport'  =>  'refresh'
    ));
    $wp_customize->add_control('texttopikterkini' , array(
      'section' => 'block_id2',
      'label' => __('Replacement for "Latest Topics" Text in Homepage', 'kibaran'),
      'type'=>'text',
      'priority' => 3,
    ));
// Text Berita Terkini
    $wp_customize->add_setting( 'textberitaterkini' , array(
      'default'    => '',
      'transport'  =>  'refresh'
    ));
    $wp_customize->add_control('textberitaterkini' , array(
      'section' => 'block_id2',
      'label' => __('Replacement for "Recent News" Text ("Normal" Homepage Type).', 'kibaran'),
      'type'=>'text',
      'priority' => 3,
    ));
    $wp_customize->add_setting( 'textsebelumnya' , array(
      'default'    => '',
      'transport'  =>  'refresh'
    ));
    $wp_customize->add_control('textsebelumnya' , array(
      'section' => 'block_id2',
      'label' => __('Replacement for Previous Button Text ("Normal" Homepage Type).', 'kibaran'),
      'type'=>'text',
      'priority' => 3,
    ));
    $wp_customize->add_setting( 'textselanjutnya' , array(
      'default'    => '',
      'transport'  =>  'refresh'
    ));
    $wp_customize->add_control('textselanjutnya' , array(
      'section' => 'block_id2',
      'label' => __('Replacement for Next Button Text ("Normal" Homepage Type).', 'kibaran'),
      'type'=>'text',
      'priority' => 3,
    ));

    $wp_customize->add_setting( 'textterbarudi' , array(
      'default'    => '',
      'transport'  =>  'refresh'
    ));
    $wp_customize->add_control('textterbarudi' , array(
      'section' => 'block_id2',
      'label' => __('Replacement for "Latest in" Text ("Category Block" Homepage Type).', 'kibaran'),
      'type'=>'text',
      'priority' => 3,
    ));

    $wp_customize->add_setting( 'texttrendingdi' , array(
      'default'    => '',
      'transport'  =>  'refresh'
    ));
    $wp_customize->add_control('texttrendingdi' , array(
      'section' => 'block_id2',
      'label' => __('Replacement for "Trending on" Text ("Category Block" Homepage Type).', 'kibaran'),
      'type'=>'text',
      'priority' => 3,
    ));

    $wp_customize->add_setting( 'textlihatlainnya' , array(
      'default'    => '',
      'transport'  =>  'refresh'
    ));
    $wp_customize->add_control('textlihatlainnya' , array(
      'section' => 'block_id2',
      'label' => __('Replacement for "See More" Text ("Category Block" Homepage Type).', 'kibaran'),
      'type'=>'text',
      'priority' => 3,
    ));

// Create settings disable tanggal post
$wp_customize->add_setting( 'aktifscrooltotop' , array(
    'sanitize_callback' => 'wp_filter_nohtml_kses', //removes all HTML from content
    'type'          => 'theme_mod',
    'transport'     => 'refresh',
    'default' => 'enable',
) );


// Create control disable tanggal post 
$wp_customize->add_control( 'aktifscrooltotop', array(
    'label'      => __('Disable Scroll to Top Button', 'kibaran'),
    'section'    => 'block_id2',
    'settings'   => 'aktifscrooltotop',
    'type'       => 'radio',
        'choices'    => array( 
          'disable' => 'Disable',
          'enable' => 'Enable',
        ),
) );


/** WAKTU TRENDING **/
    
$wp_customize->add_section( 'trending_block_id' , array(
    'title'             => 'Trending Block',
    'panel'             => 'depan_id',
    'description' => __('<b>Note:</b> Select a time range for "Trading Block"', 'kibaran'),
    'priority' => 5,
) );
    
    
// add setting trending block 1 
$wp_customize->add_setting( 'trending-1-id', array(
  'capability' => 'edit_theme_options',
  'sanitize_callback' => 'trending_sanitize_select',
  'default' => ''
) );
    
// add control trending block 1 
$wp_customize->add_control( 'trending-1-id', array(
  'type' => 'select',
  'section' => 'trending_block_id',
  'label' => __( 'Trending Block 1',  'kibaran' ),
  'description' => __( 'Select the trending time range for Block 1', 'kibaran'  ),
  'choices' => array(
    'last24hours' => __( 'Last 24 Hours', 'kibaran'  ),
    'last7days' => __( 'The last week', 'kibaran'  ),
    'last30days' => __( 'Last Month', 'kibaran'  ),
     'all' => __( 'All the time', 'kibaran'  ),
  ),
) );
    
// add setting trending block 2     
$wp_customize->add_setting( 'trending-2-id', array(
  'capability' => 'edit_theme_options',
  'sanitize_callback' => 'trending_sanitize_select',
  'default' => '',
) );

// add control trending block 2
$wp_customize->add_control( 'trending-2-id', array(
  'type' => 'select',
  'section' => 'trending_block_id',
  'label' => __( 'Trending Block 2',  'kibaran' ),
  'description' => __( 'Select the trending time range for Block 2', 'kibaran'  ),
  'choices' => array(
    'last24hours' => __( 'Last 24 Hours', 'kibaran'  ),
    'last7days' => __( 'The last week', 'kibaran'  ),
    'last30days' => __( 'Last Month', 'kibaran'  ),
     'all' => __( 'All the time', 'kibaran'  ),
  )
) );
    
// add setting trending block 3 
$wp_customize->add_setting( 'trending-3-id', array(
  'capability' => 'edit_theme_options',
  'sanitize_callback' => 'trending_sanitize_select',
  'default' => '',
) );

// add control trending block 3
$wp_customize->add_control( 'trending-3-id', array(
  'type' => 'select',
  'section' => 'trending_block_id',
  'label' => __( 'Trending Block 3',  'kibaran' ),
  'description' => __( 'Select the trending time range for Block 3', 'kibaran'  ),
  'choices' => array(
    'last24hours' => __( 'Last 24 Hours', 'kibaran'  ),
    'last7days' => __( 'The last week', 'kibaran'  ),
    'last30days' => __( 'Last Month', 'kibaran'  ),
     'all' => __( 'All the time', 'kibaran'  ),
  )
) );
    

// add setting trending block 4
$wp_customize->add_setting( 'trending-4-id', array(
  'capability' => 'edit_theme_options',
  'sanitize_callback' => 'trending_sanitize_select',
  'default' => '',
) );

// add control trending block 4
$wp_customize->add_control( 'trending-4-id', array(
  'type' => 'select',
  'section' => 'trending_block_id',
  'label' => __( 'Trending Block 4',  'kibaran' ),
  'description' => __( 'Select the trending time range for Block 4', 'kibaran'  ),
  'choices' => array(
    'last24hours' => __( 'Last 24 Hours', 'kibaran'  ),
    'last7days' => __( 'The last week', 'kibaran'  ),
    'last30days' => __( 'Last Month', 'kibaran'  ),
     'all' => __( 'All the time', 'kibaran'  ),
  )
) );
    

// add setting trending block 5
$wp_customize->add_setting( 'trending-5-id', array(
  'capability' => 'edit_theme_options',
  'sanitize_callback' => 'trending_sanitize_select',
  'default' => '',
) );

// add control trending block 5
$wp_customize->add_control( 'trending-5-id', array(
  'type' => 'select',
  'section' => 'trending_block_id',
  'label' => __( 'Trending Block 5',  'kibaran' ),
  'description' => __( 'Select the trending time range for Block 5', 'kibaran'  ),
  'choices' => array(
    'last24hours' => __( 'Last 24 Hours', 'kibaran'  ),
    'last7days' => __( 'The last week', 'kibaran'  ),
    'last30days' => __( 'Last Month', 'kibaran'  ),
     'all' => __( 'All the time', 'kibaran'  ),
  )
) );
    

// add setting trending block 6
$wp_customize->add_setting( 'trending-6-id', array(
  'capability' => 'edit_theme_options',
  'sanitize_callback' => 'trending_sanitize_select',
  'default' => '',
) );

// add control trending block 6
$wp_customize->add_control( 'trending-6-id', array(
  'type' => 'select',
  'section' => 'trending_block_id',
  'label' => __( 'Trending Block 6',  'kibaran' ),
  'description' => __( 'Select the trending time range for Block 6',  'kibaran' ),
  'choices' => array(
    'last24hours' => __( 'Last 24 Hours',  'kibaran' ),
    'last7days' => __( 'The last week',  'kibaran' ),
    'last30days' => __( 'Last Month',  'kibaran' ),
   'all' => __( 'All the time',  'kibaran' ),
  )
) );
    

// add setting trending block 7
$wp_customize->add_setting( 'trending-7-id', array(
  'capability' => 'edit_theme_options',
  'sanitize_callback' => 'trending_sanitize_select',
  'default' => '',
) );

// add control trending block 7
$wp_customize->add_control( 'trending-7-id', array(
  'type' => 'select',
  'section' => 'trending_block_id',
  'label' => __( 'Trending Block 7',  'kibaran' ),
  'description' => __( 'Select the trending time range for Block 7',  'kibaran' ),
  'choices' => array(
    'last24hours' => __( 'Last 24 Hours',  'kibaran' ),
    'last7days' => __( 'The last week',  'kibaran' ),
    'last30days' => __( 'Last Month',  'kibaran' ),
   'all' => __( 'All the time',  'kibaran' ),
  )
) );

    
// add setting trending block 8
$wp_customize->add_setting( 'trending-8-id', array(
  'capability' => 'edit_theme_options',
  'sanitize_callback' => 'trending_sanitize_select',
  'default' => '',
) );

// add control trending block 8
$wp_customize->add_control( 'trending-8-id', array(
  'type' => 'select',
  'section' => 'trending_block_id',
  'label' => __( 'Trending Block 8',  'kibaran' ),
  'description' => __( 'Select the trending time range for Block 8',  'kibaran' ),
  'choices' => array(
    'last24hours' => __( 'Last 24 Hours',  'kibaran' ),
    'last7days' => __( 'The last week',  'kibaran' ),
    'last30days' => __( 'Last Month',  'kibaran' ),
   'all' => __( 'All the time',  'kibaran' ),
  )
) );

// add setting trending block 9
$wp_customize->add_setting( 'trending-9-id', array(
  'capability' => 'edit_theme_options',
  'sanitize_callback' => 'trending_sanitize_select',
  'default' => '',
) );

// add control trending block 9
$wp_customize->add_control( 'trending-9-id', array(
  'type' => 'select',
  'section' => 'trending_block_id',
  'label' => __( 'Trending Block 9',  'kibaran'),
  'description' => __( 'Select the trending time range for Block 9',  'kibaran' ),
  'choices' => array(
    'last24hours' => __( 'Last 24 Hours',  'kibaran' ),
    'last7days' => __( 'The last week',  'kibaran' ),
    'last30days' => __( 'Last Month',  'kibaran' ),
   'all' => __( 'All the time',  'kibaran' ),
  )
) );

// add setting trending block 10
$wp_customize->add_setting( 'trending-10-id', array(
  'capability' => 'edit_theme_options',
  'sanitize_callback' => 'trending_sanitize_select',
  'default' => '',
) );

// add control trending block 10
$wp_customize->add_control( 'trending-10-id', array(
  'type' => 'select',
  'section' => 'trending_block_id',
  'label' => __( 'Trending Block 10',  'kibaran' ),
  'description' => __( 'Select the trending time range for Block 10',  'kibaran' ),
  'choices' => array(
    'last24hours' => __( 'Last 24 Hours',  'kibaran' ),
    'last7days' => __( 'The last week',  'kibaran' ),
    'last30days' => __( 'Last Month',  'kibaran' ),
   'all' => __( 'All the time',  'kibaran' ),
  )
) );
    
// add setting trending block 11
$wp_customize->add_setting( 'trending-11-id', array(
  'capability' => 'edit_theme_options',
  'sanitize_callback' => 'trending_sanitize_select',
  'default' => '',
) );

// add control trending block 11
$wp_customize->add_control( 'trending-11-id', array(
  'type' => 'select',
  'section' => 'trending_block_id',
  'label' => __( 'Trending Block 11',  'kibaran' ),
  'description' => __( 'Select the trending time range for Block 11',  'kibaran' ),
  'choices' => array(
    'last24hours' => __( 'Last 24 Hours',  'kibaran' ),
    'last7days' => __( 'The last week',  'kibaran' ),
    'last30days' => __( 'Last Month',  'kibaran' ),
   'all' => __( 'All the time',  'kibaran' ),
  )
) );
    
// add setting trending block 12
$wp_customize->add_setting( 'trending-12-id', array(
  'capability' => 'edit_theme_options',
  'sanitize_callback' => 'trending_sanitize_select',
  'default' => '',
) );

// add control trending block 12
$wp_customize->add_control( 'trending-12-id', array(
  'type' => 'select',
  'section' => 'trending_block_id',
  'label' => __( 'Trending Block 12',  'kibaran' ),
  'description' => __( 'Select the trending time range for Block 12',  'kibaran' ),
  'choices' => array(
    'last24hours' => __( 'Last 24 Hours',  'kibaran' ),
    'last7days' => __( 'The last week',  'kibaran' ),
    'last30days' => __( 'Last Month',  'kibaran' ),
   'all' => __( 'All the time',  'kibaran' ),
  )
) );
    
// add setting trending block 13
$wp_customize->add_setting( 'trending-13-id', array(
  'capability' => 'edit_theme_options',
  'sanitize_callback' => 'trending_sanitize_select',
  'default' => '',
) );

// add control trending block 13
$wp_customize->add_control( 'trending-13-id', array(
  'type' => 'select',
  'section' => 'trending_block_id',
  'label' => __( 'Trending Block 13',  'kibaran' ),
  'description' => __( 'Select the trending time range for Block 13',  'kibaran' ),
  'choices' => array(
    'last24hours' => __( 'Last 24 Hours',  'kibaran' ),
    'last7days' => __( 'The last week',  'kibaran' ),
    'last30days' => __( 'Last Month',  'kibaran' ),
   'all' => __( 'All the time',  'kibaran' ),
  )
) );
    
// add setting trending block 14
$wp_customize->add_setting( 'trending-14-id', array(
  'capability' => 'edit_theme_options',
  'sanitize_callback' => 'trending_sanitize_select',
  'default' => '',
) );

// add control trending block 14
$wp_customize->add_control( 'trending-14-id', array(
  'type' => 'select',
  'section' => 'trending_block_id',
  'label' => __( 'Trending Block 14',  'kibaran' ),
  'description' => __( 'Select the trending time range for Block 14',  'kibaran' ),
  'choices' => array(
    'last24hours' => __( 'Last 24 Hours',  'kibaran' ),
    'last7days' => __( 'The last week',  'kibaran' ),
    'last30days' => __( 'Last Month',  'kibaran' ),
   'all' => __( 'All the time',  'kibaran' ),
  )
) );
    
// add setting trending block 15
$wp_customize->add_setting( 'trending-15-id', array(
  'capability' => 'edit_theme_options',
  'sanitize_callback' => 'trending_sanitize_select',
  'default' => '',
) );

// add control trending block 15
$wp_customize->add_control( 'trending-15-id', array(
  'type' => 'select',
  'section' => 'trending_block_id',
  'label' => __( 'Trending Block 15',  'kibaran' ),
  'description' => __( 'Select the trending time range for Block 15',  'kibaran' ),
  'choices' => array(
    'last24hours' => __( 'Last 24 Hours',  'kibaran' ),
    'last7days' => __( 'The last week',  'kibaran' ),
    'last30days' => __( 'Last Month',  'kibaran' ),
   'all' => __( 'All the time',  'kibaran' ),
  )
) );

// add setting trending block 16
$wp_customize->add_setting( 'trending-16-id', array(
  'capability' => 'edit_theme_options',
  'sanitize_callback' => 'trending_sanitize_select',
  'default' => '',
) );

// add control trending block 16
$wp_customize->add_control( 'trending-16-id', array(
  'type' => 'select',
  'section' => 'trending_block_id',
  'label' => __( 'Trending Block 16',  'kibaran' ),
  'description' => __( 'Select the trending time range for Block 16',  'kibaran' ),
  'choices' => array(
    'last24hours' => __( 'Last 24 Hours',  'kibaran' ),
    'last7days' => __( 'The last week',  'kibaran' ),
    'last30days' => __( 'Last Month',  'kibaran' ),
   'all' => __( 'All the time',  'kibaran' ),
  )
) );
    
// add setting trending block 17
$wp_customize->add_setting( 'trending-17-id', array(
  'capability' => 'edit_theme_options',
  'sanitize_callback' => 'trending_sanitize_select',
  'default' => '',
) );

// add control trending block 17
$wp_customize->add_control( 'trending-17-id', array(
  'type' => 'select',
  'section' => 'trending_block_id',
  'label' => __( 'Trending Block 17',  'kibaran' ),
  'description' => __( 'Select the trending time range for Block 17',  'kibaran' ),
  'choices' => array(
    'last24hours' => __( 'Last 24 Hours',  'kibaran' ),
    'last7days' => __( 'The last week',  'kibaran' ),
    'last30days' => __( 'Last Month',  'kibaran' ),
   'all' => __( 'All the time',  'kibaran' ),
  )
) );
    
// add setting trending block 18
$wp_customize->add_setting( 'trending-18-id', array(
  'capability' => 'edit_theme_options',
  'sanitize_callback' => 'trending_sanitize_select',
  'default' => '',
) );

// add control trending block 18
$wp_customize->add_control( 'trending-18-id', array(
  'type' => 'select',
  'section' => 'trending_block_id',
  'label' => __( 'Trending Block 18',  'kibaran' ),
  'description' => __( 'Select the trending time range for Block 18',  'kibaran' ),
  'choices' => array(
    'last24hours' => __( 'Last 24 Hours',  'kibaran' ),
    'last7days' => __( 'The last week',  'kibaran' ),
    'last30days' => __( 'Last Month',  'kibaran' ),
   'all' => __( 'All the time',  'kibaran' ),
  )
) );
    
// add setting trending block 19
$wp_customize->add_setting( 'trending-19-id', array(
  'capability' => 'edit_theme_options',
  'sanitize_callback' => 'trending_sanitize_select',
  'default' => '',
) );

// add control trending block 19
$wp_customize->add_control( 'trending-19-id', array(
  'type' => 'select',
  'section' => 'trending_block_id',
  'label' => __( 'Trending Block 19',  'kibaran' ),
  'description' => __( 'Select the trending time range for Block 19',  'kibaran' ),
  'choices' => array(
    'last24hours' => __( 'Last 24 Hours',  'kibaran' ),
    'last7days' => __( 'The last week',  'kibaran' ),
    'last30days' => __( 'Last Month',  'kibaran' ),
   'all' => __( 'All the time',  'kibaran' ),
  )
) );
    
// add setting trending block 20
$wp_customize->add_setting( 'trending-20-id', array(
  'capability' => 'edit_theme_options',
  'sanitize_callback' => 'trending_sanitize_select',
  'default' => '',
) );

// add control trending block 20
$wp_customize->add_control( 'trending-20-id', array(
  'type' => 'select',
  'section' => 'trending_block_id',
  'label' => __( 'Trending Block 20',  'kibaran' ),
  'description' => __( 'Select the trending time range for Block 20',  'kibaran' ),
  'choices' => array(
    'last24hours' => __( 'Last 24 Hours',  'kibaran' ),
    'last7days' => __( 'The last week',  'kibaran' ),
    'last30days' => __( 'Last Month',  'kibaran' ),
   'all' => __( 'All the time',  'kibaran' ),
  )
) );
    
// add setting trending block 21
$wp_customize->add_setting( 'trending-21-id', array(
  'capability' => 'edit_theme_options',
  'sanitize_callback' => 'trending_sanitize_select',
  'default' => '',
) );

// add control trending block 21
$wp_customize->add_control( 'trending-21-id', array(
  'type' => 'select',
  'section' => 'trending_block_id',
  'label' => __( 'Trending Block 21',  'kibaran' ),
  'description' => __( 'Select the trending time range for Block 21',  'kibaran' ),
  'choices' => array(
    'last24hours' => __( 'Last 24 Hours',  'kibaran' ),
    'last7days' => __( 'The last week',  'kibaran' ),
    'last30days' => __( 'Last Month',  'kibaran' ),
   'all' => __( 'All the time',  'kibaran' ),
  )
) );
    
// add setting trending block 22
$wp_customize->add_setting( 'trending-22-id', array(
  'capability' => 'edit_theme_options',
  'sanitize_callback' => 'trending_sanitize_select',
  'default' => '',
) );

// add control trending block 22
$wp_customize->add_control( 'trending-22-id', array(
  'type' => 'select',
  'section' => 'trending_block_id',
  'label' => __( 'Trending Block 22',  'kibaran' ),
  'description' => __( 'Select the trending time range for Block 22',  'kibaran' ),
  'choices' => array(
    'last24hours' => __( 'Last 24 Hours',  'kibaran' ),
    'last7days' => __( 'The last week',  'kibaran' ),
    'last30days' => __( 'Last Month',  'kibaran' ),
   'all' => __( 'All the time',  'kibaran' ),
  )
) );
    
// add setting trending block 23
$wp_customize->add_setting( 'trending-23-id', array(
  'capability' => 'edit_theme_options',
  'sanitize_callback' => 'trending_sanitize_select',
  'default' => '',
) );

// add control trending block 23
$wp_customize->add_control( 'trending-23-id', array(
  'type' => 'select',
  'section' => 'trending_block_id',
  'label' => __( 'Trending Block 23',  'kibaran' ),
  'description' => __( 'Select the trending time range for Block 23',  'kibaran' ),
  'choices' => array(
    'last24hours' => __( 'Last 24 Hours',  'kibaran' ),
    'last7days' => __( 'The last week',  'kibaran' ),
    'last30days' => __( 'Last Month',  'kibaran' ),
   'all' => __( 'All the time',  'kibaran' ),
  )
) );
    
// add setting trending block 24
$wp_customize->add_setting( 'trending-24-id', array(
  'capability' => 'edit_theme_options',
  'sanitize_callback' => 'trending_sanitize_select',
  'default' => '',
) );

// add control trending block 24
$wp_customize->add_control( 'trending-24-id', array(
  'type' => 'select',
  'section' => 'trending_block_id',
  'label' => __( 'Trending Block 24',  'kibaran' ),
  'description' => __( 'Select the trending time range for Block 24',  'kibaran' ),
  'choices' => array(
    'last24hours' => __( 'Last 24 Hours',  'kibaran' ),
    'last7days' => __( 'The last week',  'kibaran' ),
    'last30days' => __( 'Last Month',  'kibaran' ),
   'all' => __( 'All the time',  'kibaran' ),
  )
) );
    
// add setting trending block 25
$wp_customize->add_setting( 'trending-25-id', array(
  'capability' => 'edit_theme_options',
  'sanitize_callback' => 'trending_sanitize_select',
  'default' => '',
) );

// add control trending block 25
$wp_customize->add_control( 'trending-25-id', array(
  'type' => 'select',
  'section' => 'trending_block_id',
  'label' => __( 'Trending Block 25',  'kibaran' ),
  'description' => __( 'Select the trending time range for Block 25',  'kibaran' ),
  'choices' => array(
    'last24hours' => __( 'Last 24 Hours',  'kibaran' ),
    'last7days' => __( 'The last week',  'kibaran' ),
    'last30days' => __( 'Last Month',  'kibaran' ),
   'all' => __( 'All the time',  'kibaran' ),
  )
) );
    
// add setting trending block 26
$wp_customize->add_setting( 'trending-26-id', array(
  'capability' => 'edit_theme_options',
  'sanitize_callback' => 'trending_sanitize_select',
  'default' => '',
) );

// add control trending block 26
$wp_customize->add_control( 'trending-26-id', array(
  'type' => 'select',
  'section' => 'trending_block_id',
  'label' => __( 'Trending Block 26',  'kibaran' ),
  'description' => __( 'Select the trending time range for Block 26',  'kibaran' ),
  'choices' => array(
    'last24hours' => __( 'Last 24 Hours',  'kibaran' ),
    'last7days' => __( 'The last week',  'kibaran' ),
    'last30days' => __( 'Last Month',  'kibaran' ),
   'all' => __( 'All the time',  'kibaran' ),
  )
) );
    
// add setting trending block 27
$wp_customize->add_setting( 'trending-27-id', array(
  'capability' => 'edit_theme_options',
  'sanitize_callback' => 'trending_sanitize_select',
  'default' => '',
) );

// add control trending block 27
$wp_customize->add_control( 'trending-27-id', array(
  'type' => 'select',
  'section' => 'trending_block_id',
  'label' => __( 'Trending Block 27',  'kibaran' ),
  'description' => __( 'Select the trending time range for Block 27',  'kibaran' ),
  'choices' => array(
    'last24hours' => __( 'Last 24 Hours',  'kibaran' ),
    'last7days' => __( 'The last week',  'kibaran' ),
    'last30days' => __( 'Last Month',  'kibaran' ),
   'all' => __( 'All the time',  'kibaran' ),
  )
) );
    
// add setting trending block 28
$wp_customize->add_setting( 'trending-28-id', array(
  'capability' => 'edit_theme_options',
  'sanitize_callback' => 'trending_sanitize_select',
  'default' => '',
) );

// add control trending block 28
$wp_customize->add_control( 'trending-28-id', array(
  'type' => 'select',
  'section' => 'trending_block_id',
  'label' => __( 'Trending Block 28',  'kibaran' ),
  'description' => __( 'Select the trending time range for Block 28',  'kibaran' ),
  'choices' => array(
    'last24hours' => __( 'Last 24 Hours',  'kibaran' ),
    'last7days' => __( 'The last week',  'kibaran' ),
    'last30days' => __( 'Last Month',  'kibaran' ),
   'all' => __( 'All the time',  'kibaran' ),
  )
) );
    
// add setting trending block 29
$wp_customize->add_setting( 'trending-29-id', array(
  'capability' => 'edit_theme_options',
  'sanitize_callback' => 'trending_sanitize_select',
  'default' => '',
) );

// add control trending block 29
$wp_customize->add_control( 'trending-29-id', array(
  'type' => 'select',
  'section' => 'trending_block_id',
  'label' => __( 'Trending Block 29',  'kibaran' ),
  'description' => __( 'Select the trending time range for Block 29',  'kibaran' ),
  'choices' => array(
    'last24hours' => __( 'Last 24 Hours',  'kibaran' ),
    'last7days' => __( 'The last week',  'kibaran' ),
    'last30days' => __( 'Last Month',  'kibaran' ),
   'all' => __( 'All the time',  'kibaran' ),
  )
) );
    
// add setting trending block 30
$wp_customize->add_setting( 'trending-30-id', array(
  'capability' => 'edit_theme_options',
  'sanitize_callback' => 'trending_sanitize_select',
  'default' => '',
) );

// add control trending block 30
$wp_customize->add_control( 'trending-30-id', array(
  'type' => 'select',
  'section' => 'trending_block_id',
  'label' => __( 'Trending Block 30',  'kibaran' ),
  'description' => __( 'Select the trending time range for Block 30',  'kibaran' ),
  'choices' => array(
    'last24hours' => __( 'Last 24 Hours',  'kibaran' ),
    'last7days' => __( 'The last week',  'kibaran' ),
    'last30days' => __( 'Last Month',  'kibaran' ),
   'all' => __( 'All the time',  'kibaran' ),
  )
) );
    

function trending_sanitize_select( $input, $setting ) {

  // Ensure input is a slug.
  $input = sanitize_key( $input );

  // Get list of choices from the control associated with the setting.
  $choices = $setting->manager->get_control( $setting->id )->choices;

  // If the input is a valid key, return it; otherwise, return the default.
  return ( array_key_exists( $input, $choices ) ? $input : $setting->default );
}
    
// Create section Perataan Menu Utama
//$wp_customize->add_section( 'alignmenu_id' , array(
//  'title'             => __('Menu Settings', 'kibaran'),
//  'panel'             => 'depan_id',
//    'priority' => 6,
//) );
    
// Create settings alignmenu
//$wp_customize->add_setting( 'alignmenu' , array(
//  'sanitize_callback' => 'wp_filter_nohtml_kses', //removes all HTML from content
//  'type'          => 'theme_mod',
//  'transport'     => 'refresh',
//) );
    
//// Create control alignmenu
//$wp_customize->add_control( 'alignmenu', array(
//  'label'      => 'Perataan Menu Utama',
//  'section'    => 'alignmenu_id',
//  'settings'   => 'alignmenu',
//  'type'       => 'radio',
//        'choices'    => array( 
  //        'left' => 'Rata Kiri',
 //         'center' => 'Rata Tengah',
//        ),
//) );
    


    

// Create settings Arrow Menu Button
//$wp_customize->add_setting( 'arrowbutton' , array(
//  'sanitize_callback' => 'wp_filter_nohtml_kses', //removes all HTML from content
//  'type'          => 'theme_mod',
//  'transport'     => 'refresh',
//) );


// Create control Arrow Menu Button
//$wp_customize->add_control( 'arrowbutton', array(
//  'label'      => 'Hide Arrow Primary Menu Button Icon',
//  'section'    => 'alignmenu_id',
//  'settings'   => 'arrowbutton',
//  'type'       => 'radio',
//        'choices'    => array( 
//          'show' => 'Show',
//          'hide' => 'Hide',
//        ),
//) );
    
// Pengaturan Post
$wp_customize->add_section( 'postsettings' , array(
    'title'             => __('Post Settings', 'kibaran'),
    'panel'             => 'depan_id',
    'priority' => 7,
) );
   

// Create settings disable tanggal post
$wp_customize->add_setting( 'gambarpost' , array(
      'default'    => 0,
      'transport'  => 'refresh'
) );

// Create control disable tanggal post 
$wp_customize->add_control( 'gambarpost', array(
    'label'      => __('Disable Featured Image on Post Pages', 'kibaran'),
    'section'    => 'postsettings',
    'type'       => 'checkbox',
    'default'       => 0,
) );

// Create settings disable tanggal post
$wp_customize->add_setting( 'gambarpage' , array(
      'default'    => 0,
      'transport'  => 'refresh'
) );


// Create control disable tanggal post 
$wp_customize->add_control( 'gambarpage', array(
    'label'      => __('Disable Featured Image on Static Pages', 'kibaran'),
    'section'    => 'postsettings',
    'type'       => 'checkbox',
    'default'       => 0,
) );
    

// Create settings Deskripsi Kategori
$wp_customize->add_setting( 'deskripsikategori' , array(
      'default'    => 0,
      'transport'  => 'refresh'
) );


// Create control Deskripsi Kategori
$wp_customize->add_control( 'deskripsikategori', array(
    'label'      => __('Disable Category Description', 'kibaran'),
    'section'    => 'postsettings',
    'settings'   => 'deskripsikategori',
    'type'       => 'checkbox',
) );

// Create settings Deskripsi Tag
$wp_customize->add_setting( 'deskripsitag' , array(
      'default'    => 0,
      'transport'  => 'refresh'
) );


// Create control Deskripsi Kategori
$wp_customize->add_control( 'deskripsitag', array(
    'label'      => __('Disable Tag Description', 'kibaran'),
    'section'    => 'postsettings',
    'type'       => 'checkbox',
    'default'       => 0,
) );

// Create Post View settings
$wp_customize->add_setting( 'jumlahpembaca' , array(
      'default'    => 0,
      'transport'  => 'refresh'
) );


// Create Post view control
$wp_customize->add_control( 'jumlahpembaca', array(
    'label'      => __('Hide Post View','kibaran'),
    'section'    => 'postsettings',
    'type'       => 'checkbox',
    'default'       => 0,
) ); 

// Create Comment Icon settings
$wp_customize->add_setting( 'commenticon' , array(
      'default'    => 0,
      'transport'  => 'refresh'
) );


// Create control Comment Icon settings
$wp_customize->add_control( 'commenticon', array(
    'label'         => __('Hide Comment Icon', 'kibaran'),
    'section'       => 'postsettings',
    'type'          => 'checkbox',
    'default'       => 0,
) );

// Create settings disable tanggal post
$wp_customize->add_setting( 'tanggalpost' , array(
      'default'    => 0,
      'transport'  => 'refresh'
) );


// Create control disable tanggal post 
$wp_customize->add_control( 'tanggalpost', array(
    'label'         => __('Hide Post Date', 'kibaran'),
    'section'       => 'postsettings',
    'type'          => 'checkbox',
    'default'       => 0,
) );    
    
// Create settings disable waktu jam post 
$wp_customize->add_setting( 'waktupost' , array(
      'default'    => 0,
      'transport'  => 'refresh'
) );


// Create control disable waktu jam post 
$wp_customize->add_control( 'waktupost', array(
    'label'         => __('Hide Post Time', 'kibaran'),
    'section'       => 'postsettings',
    'type'          => 'checkbox',
    'default'       => 0,
) );

// Create Sidebar Post settings
$wp_customize->add_setting( 'hidesidebar' , array(
      'default'    => 0,
      'transport'  => 'refresh'
) );


// Create Sidebar Post control
$wp_customize->add_control( 'hidesidebar', array(
    'label'      => __('Hide Sidebar on Single Post when accessed via mobile','kibaran'),
    'section'    => 'postsettings',
    'type'       => 'checkbox',
    'default'       => 0,
) ); 

// Create settings waktu indonesia
$wp_customize->add_setting( 'zonawaktu' , array(
      'sanitize_callback' => 'wp_filter_nohtml_kses', //removes all HTML from content
    'type'          => 'theme_mod',
    'transport'     => 'refresh'
) );  
    
// add control waktu indonesia
$wp_customize->add_control( 'zonawaktu', array(
  'type' => 'select',
  'section' => 'postsettings',
  'label' => esc_html__( 'Indonesian Time Zone', 'kibaran' ),
  'choices' => array(
    'WIB' => esc_html__( 'WIB', 'kibaran'  ),
    'WITA' => esc_html__( 'WITA', 'kibaran'  ),
    'WIT' => esc_html__( 'WIT', 'kibaran'  ),
   '' => esc_html__( 'Empty', 'kibaran'  ),
  )
) );
    
// Create settings Ganti istilah writer
$wp_customize->add_setting( 'writer' , array(
  'sanitize_callback' => 'wp_filter_nohtml_kses', //removes all HTML from content
  'type'          => 'theme_mod',
  'transport'     => 'refresh',
) );


// add control Ganti istilah writer
$wp_customize->add_control( 'writer', array(
  'type' => 'select',
  'section' => 'postsettings',
  'label' => __( 'Replace the term of "Writer"', 'kibaran'  ),
  'choices' => array(
    'Penulis' => esc_html__( 'Penulis', 'kibaran'  ),
    'Penulis Berita' => esc_html__( 'Penulis Berita', 'kibaran'  ),
    'Reporter' => esc_html__( 'Reporter', 'kibaran'  ),
    'Writer' => esc_html__( 'Writer', 'kibaran'  ),
  'Redaksi' => esc_html__( 'Redaksi', 'kibaran'  ),
  'Redaktur' => esc_html__( 'Redaktur', 'kibaran'  ),
    'Team' => esc_html__( 'Team', 'kibaran'  ),
    'Tim' => esc_html__( 'Tim', 'kibaran'  ),
    'Editor' => esc_html__( 'Editor', 'kibaran'  ),
    'Editorial Team' => esc_html__( 'Editorial Team', 'kibaran'  ),
    'Editorial Staff' => esc_html__( 'Editorial Staff', 'kibaran'  ),
    'Author' => esc_html__( 'Author', 'kibaran'  ),
    'Co-Author' => esc_html__( 'Co-Author', 'kibaran'  ),
    'Kontributor' => esc_html__( 'Kontributor', 'kibaran'  ),
    'Wartawan' => esc_html__( 'Wartawan', 'kibaran'  ),
    'Jurnalis' => esc_html__( 'Jurnalis', 'kibaran'  ),
    'Pewarta' => esc_html__( 'Pewarta', 'kibaran'  ),
    'Publisher' => esc_html__( 'Publisher', 'kibaran'  ),
    'Pengarang' => esc_html__( 'Pengarang', 'kibaran'  ),
    'Pengarang Cerita' => esc_html__( 'Pengarang Cerita', 'kibaran'  ),
    'Novelis' => esc_html__( 'Novelis', 'kibaran'  ),
    'Cerpenis' => esc_html__( 'Cerpenis', 'kibaran'  ),
    'Admin' => esc_html__( 'Admin', 'kibaran'  ),
    'Administrator' => esc_html__( 'Administrator', 'kibaran'  ),
    'Tim Kreatif' => esc_html__( 'Tim Kreatif', 'kibaran'  ),
    'Peneliti' => esc_html__( 'Peneliti', 'kibaran'  ),
    'Guru' => esc_html__( 'Guru', 'kibaran'  ),
    'Dosen' => esc_html__( 'Dosen', 'kibaran'  ),
    'Dokter' => esc_html__( 'Dokter', 'kibaran'  ),
    'Bidan' => esc_html__( 'Bidan', 'kibaran'  ),
    'Freelancer' => esc_html__( 'Freelancer', 'kibaran'  ),
    'Assistant' => esc_html__( 'Assistant', 'kibaran'  ),
    'Staff' => esc_html__( 'Staff', 'kibaran'  ),
  )
) );


// Create settings comment selected
$wp_customize->add_setting( 'commenttype' , array(
    'sanitize_callback' => 'wp_filter_nohtml_kses', //removes all HTML from content
    'type'          => 'theme_mod',
    'transport'     => 'refresh',
    'default'       => 'default',
) );

// Create control comment selected
$wp_customize->add_control( 'commenttype', array(
    'label'      => __('Comment type', 'kibaran'),
    'section'    => 'postsettings',
    'settings'   => 'commenttype',
    'type'       => 'radio',
        'choices'    => array( 
          'default' => 'Default',
          'fb' => 'Facebook (Wpdevart Social comments plugin require)',
        ),
) );


    $wp_customize->add_setting( 'postrelated' , array(
      'default'    => '0',
      'transport'  =>  'refresh'
    ));
    $wp_customize->add_control('postrelated' , array(
      'section' => 'postsettings',
      'label' => __('Enable Related Posts in Article(Based on the same Category)', 'kibaran'),
      'description'=> __('Enter the position of the related post you want to display. Example: <b style="color: red">1, 2, 3</b>. Then related posts will be displayed after paragraphs 1, 2 and 3.', 'kibaran'),
      'type'=>'text',
    ));

    $wp_customize->add_setting( 'postrelatedbytag' , array(
      'default'    => '0',
      'transport'  =>  'refresh'
    ));
    $wp_customize->add_control('postrelatedbytag' , array(
      'section' => 'postsettings',
      'label' => __('Enable Related Posts in Article (Based on the same Tag) 2nd', 'kibaran'),
      'description'=> __('Enter the position of the related post you want to display. Example: <b style="color: red">1, 2, 3</b>. Then related posts will be displayed after paragraphs 1, 2 and 3.', 'kibaran'),
      'type'=>'text',
    ));

    $wp_customize->add_setting( 'textrelatedpost' , array(
      'default'    => '',
      'transport'  =>  'refresh'
    ));
    $wp_customize->add_control('textrelatedpost' , array(
      'section' => 'postsettings',
      'label' => __('Read More Text (Replacement for "Read More" text).', 'kibaran'),
      'type'=>'text',
      'priority' => 29,
    ));
    $wp_customize->add_setting( 'numberrelated' , array(
      'default'    => '5',
      'transport'  =>  'refresh'
    ));
    $wp_customize->add_control('numberrelated' , array(
      'section' => 'postsettings',
      'label' => __('Number Related Posts Below Comment Form', 'kibaran'),
      'description'=> __('How much number post want to display on related post below comment form', 'kibaran'),
      'type'=>'number',
        'input_attrs' => array(
          'min' =>0,
        ),
      'priority' => 29,
    ));
    $wp_customize->add_setting( 'texttrendingpostinpost' , array(
      'default'    => '',
      'transport'  =>  'refresh'
    ));
    $wp_customize->add_control('texttrendingpostinpost' , array(
      'section' => 'postsettings',
      'label' => __('Trending Post Text (Replacement for "Trending in" text).', 'kibaran'),
      'type'=>'text',
      'priority' => 30,
    ));
    $wp_customize->add_setting( 'numbertrending' , array(
      'default'    => '5',
      'transport'  =>  'refresh'
    ));
    $wp_customize->add_control('numbertrending' , array(
      'section' => 'postsettings',
      'label' => __('Number Related Posts Below Comment Form', 'kibaran'),
      'description'=> __('How much number post want to display on trending post below comment form', 'kibaran'),
      'type'=>'number',
        'input_attrs' => array(
          'min' =>0,
        ),
      'priority' => 30,
    ));
    
    // Footer Copyright =========================================================== 
    $wp_customize->add_section( 'footercopyright', array(
        'title' => 'Footer & Copyright',
        'priority' => 9,
      'panel' => 'depan_id',
      ));
    $wp_customize->add_setting( 'hidefooter' , array(
      'default'    => 0,
      'transport'  => 'refresh'
    ));
    $wp_customize->add_control('hidefooter' , array(
      'section' => 'footercopyright',
      'label' => __('Hide Footer section','kibaran'),
      'type'=> 'checkbox',
      'priority' => 1,
    ));
      $wp_customize->add_setting('footer_image', array(
          'default' => '',
          'type' => 'theme_mod',
          'transport'  =>  'refresh',
          'sanitize_callback' => 'my_customize_sanitize_footer_image',
      ));
      $wp_customize->add_control(
          new WP_Customize_Image_Control(
              $wp_customize, 'footer_image', array(
                  'label'    => 'Footer Image',
                  'settings' => 'footer_image',
                  'section'  => 'footercopyright',
                  'priority' => 1,
      )));
    $wp_customize->add_setting( 'filtercolorfooter' , array(
      'default'    => 0,
      'transport'  => 'refresh'
    ));
    $wp_customize->add_control('filtercolorfooter' , array(
      'section' => 'footercopyright',
      'label' => __('Change the Footer Logo to Black and White', 'kibaran'),
      'type'=> 'checkbox',
      'priority' => 2,
    ));
    $wp_customize->add_setting( 'copyright' , array(
      'default'    => '',
      'transport'  =>  'refresh'
    ));
    $wp_customize->add_control('copyright' , array(
      'section' => 'footercopyright',
      'label' =>'Footer Copyright.',
      'description'=>  __('Enter your copyright text.', 'kibaran'),
      'type'=>'textarea',
      'priority' => 3,
    ));
    

    // Create section Warna Theme
/* $wp_customize->add_section( 'warnaid' , array(
    'title'             => 'Ganti Warna Theme',
    'panel'             => 'depan_id',
) );

// Create settings Warna Theme
$wp_customize->add_setting( 'warna' , array(
    'type'          => 'theme_mod',
    'transport'     => 'refresh',
) );


// Create control Warna Theme
$wp_customize->add_control( 'warna', array(
    'label'      => 'Pilih Warna Theme',
    'section'    => 'warnaid',
    'settings'   => 'warna',
    'type'       => 'radio',
        'choices'    => array( 
          'hitam' => 'Hitam',
          'biru' => 'Biru',
            'hijau' => 'Hijau',
            'merah' => 'Merah',
            'ungu' => 'Ungu',
            'kuning' => 'Kuning',
            'coklat' => 'Coklat',
            'maroon' => 'Maroon',
            'biru langit' => 'Biru Langit',
            'hijau tua' => 'Hijau Tua',
            'abu abu' => 'Abu abu',
            'pink' => 'Pink',
            'orange' => 'Orange',
            'putih' => 'Putih',
            'tosca' => 'Tosca',
            'cream' => 'Cream',
            'magenta' => 'Magenta',
            'emas' => 'Emas',
            'biru dongker' => 'Biru Dongker',
        ),
) ); */
    

}
// akhir add text box in customizer


function addCustomize2($wp_customize2) {
  $wp_customize2->add_panel( 'KibaranColor', array(
    'title' => __('Color Settings', 'kibaran'),
    'priority' => 20,
  ));

    // Warna Umum=========================================================== 
    $wp_customize2->add_section( 'warnaumum', array(
        'title' => __('General', 'kibaran'),
        'description'=> __('Change the color of the mobile version of the Chrome browser display', 'kibaran'),
      'panel' => 'KibaranColor',
      ));
      $wp_customize2->add_setting( 'themecolor' , array(
          'default'     => "#009BA9",
          'transport'   => 'refresh',
          'type'      => 'theme_mod',
      ));
      $wp_customize2->add_control( new WP_Customize_Color_Control( $wp_customize2, 'themecolor', array(
          'label'        => __('Theme Color', 'kibaran'),
          'section'      => 'warnaumum',
      )));

    // Warna Header=========================================================== 
    $wp_customize2->add_section( 'colorheader', array(
        'title' => 'Header',
      'panel' => 'KibaranColor',
      ));
      $wp_customize2->add_setting( 'warnaheader' , array(
          'default'     => "#fff",
          'transport'   => 'refresh',
      ));
      $wp_customize2->add_control( new WP_Customize_Color_Control( $wp_customize2, 'warnaheader', array(
          'label'        => __('1. Header Background Color', 'kibaran'),
          'section'    => 'colorheader',
      )));
      $wp_customize2->add_setting( 'sidemenubackg' , array(
          'default'     => "#fff",
          'transport'   => 'refresh',
      ));
      $wp_customize2->add_control( new WP_Customize_Color_Control( $wp_customize2, 'sidemenubackg', array(
          'label'        => __('2. Background Color <i><u>Side Menu (Mobile)</i></u>', 'kibaran'),
          'section'    => 'colorheader',
      )));
      $wp_customize2->add_setting( 'iconbackg' , array(
          'default'     => "#ddd",
          'transport'   => 'refresh',
      ));
      $wp_customize2->add_control( new WP_Customize_Color_Control( $wp_customize2, 'iconbackg', array(
          'label'        => __('3. Social Media Icon Background Color', 'kibaran'),
          'section'    => 'colorheader',
      )));
      $wp_customize2->add_setting( 'menuutama1' , array(
          'default'     => "#000000",
          'transport'   => 'refresh',
      ));
      $wp_customize2->add_control( new WP_Customize_Color_Control( $wp_customize2, 'menuutama1', array(
          'label'        => __('4. Text Color <i><u>Main Menu (Desktop)</i></u>', 'kibaran'),
          'section'    => 'colorheader',
      )));
      $wp_customize2->add_setting( 'listmenu' , array(
          'default'     => "#D13438",
          'transport'   => 'refresh',
      ));
      $wp_customize2->add_control( new WP_Customize_Color_Control( $wp_customize2, 'listmenu', array(
          'label'        => __('5. List Color <i><u>Main Menu Active (Desktop)</i></u>', 'kibaran'),
          'section'    => 'colorheader',
      )));

    // Warna Body=========================================================== 
    $wp_customize2->add_section( 'colorbody', array(
        'title' => 'Body',
        'panel' => 'KibaranColor',
      ));
      $wp_customize2->add_setting( 'warnabackgroundbody' , array(
          'default'     => "#fff",
          'transport'   => 'refresh',
      ));
      $wp_customize2->add_control( new WP_Customize_Color_Control( $wp_customize2, 'warnabackgroundbody', array(
          'label'        => __('1. Body Background Color', 'kibaran'),
          'section'    => 'colorbody',
      )));
      $wp_customize2->add_setting( 'ornament1' , array(
          'default'     => "#D13438",
          'transport'   => 'refresh',
      ));
      $wp_customize2->add_control( new WP_Customize_Color_Control( $wp_customize2, 'ornament1', array(
          'label'        => __('2. Title Ornament Color (1)', 'kibaran'),
          'section'    => 'colorbody',
      )));
      $wp_customize2->add_setting( 'ornament2' , array(
          'default'     => "#12A7B5",
          'transport'   => 'refresh',
      ));
      $wp_customize2->add_control( new WP_Customize_Color_Control( $wp_customize2, 'ornament2', array(
          'label'        => __('3. Title Ornament Color (2)', 'kibaran'),
          'section'    => 'colorbody',
      )));
      $wp_customize2->add_setting( 'warnatombol' , array(
          'default'     => "#009BA9",
          'transport'   => 'refresh',
      ));
      $wp_customize2->add_control( new WP_Customize_Color_Control( $wp_customize2, 'warnatombol', array(
          'label'        => __('4. Button Color', 'kibaran'),
          'section'    => 'colorbody',
      )));

    // Warna Footer=========================================================== 
    $wp_customize2->add_section( 'colorfooter', array(
        'title' => 'Footer',
        'panel' => 'KibaranColor',
      ));
      $wp_customize2->add_setting( 'warnabackgroundfooter' , array(
          'default'     => "#EDEBE9",
          'transport'   => 'refresh',
      ));
      $wp_customize2->add_control( new WP_Customize_Color_Control( $wp_customize2, 'warnabackgroundfooter', array(
          'label'        => __('1. Footer Background Color', 'kibaran'),
          'section'    => 'colorfooter',
      )));
      $wp_customize2->add_setting( 'warnascrolltop' , array(
          'default'     => "#009BA9",
          'transport'   => 'refresh',
      ));
      $wp_customize2->add_control( new WP_Customize_Color_Control( $wp_customize2, 'warnascrolltop', array(
          'label'        => __('2. Scroll to Top Button Color', 'kibaran'),
          'section'    => 'colorfooter',
      )));
      $wp_customize2->add_setting( 'iconbackgfooter' , array(
          'default'     => "#ddd",
          'transport'   => 'refresh',
      ));
      $wp_customize2->add_control( new WP_Customize_Color_Control( $wp_customize2, 'iconbackgfooter', array(
          'label'        => __('3. Social Media Footer Icon Background Color (Mobile)', 'kibaran'),
          'section'    => 'colorfooter',
      )));

}

  add_action( 'customize_register', 'addCustomize2' );


function addCustomize3($wp_customize3) {
  $wp_customize3->add_panel( 'KibaranBanner', array(
    'title' => __('Banners/ Ads', 'kibaran'),
    'priority' => 20,
  ));


        // Iklan di bawah header =========================================================== 
        $wp_customize3->add_section( 'bawahheader', array(
            'title' => __('Banner/Ads Under Header', 'kibaran'),
            'priority' => 20,
            'description'=> __('Enter your banner/ads code, size 970x250 px. For an example banner, you can enter this code:<br><b style="color: red;">&lt;img width=&quot;970&quot; height=&quot;250&quot; src=&quot;https://demo.pojoksoft.com/kibaran/wp-content/uploads/2024/01/230330-siagarafi-970x250-1-jpg.webp&quot;&gt;</b><br><br>', 'kibaran'),
            'priority' => 20,
            'panel' => 'KibaranBanner',
        ));
        $wp_customize3->add_setting( 'adsbawahheader' , array(
            'default'    => '',
            'transport'  =>  'refresh'
        ));
        $wp_customize3->add_control('adsbawahheader' , array(
            'section' => 'bawahheader',
            'type'=>'textarea',
            'priority' => 3,
        ));


        // Iklan di bawah headline =========================================================== 
        $wp_customize3->add_section( 'bawahheadline', array(
            'title' => __('Banner/Ads Below Headline', 'kibaran'),
            'description'=> __('Enter your banner/ads code, size 970x90 px. For an example banner, you can enter this code:<br><b style="color: red;">&lt;img width=&quot;970&quot; height=&quot;90&quot; src=&quot;https://demo.pojoksoft.com/kibaran/wp-content/uploads/2024/01/1115647138008519075251.jpg&quot;&gt;</b><br><br>', 'kibaran'),
            'panel' => 'KibaranBanner',
        ));
        $wp_customize3->add_setting( 'adsbawahheadline' , array(
            'default'    => '',
            'transport'  =>  'refresh'
        ));
        $wp_customize3->add_control('adsbawahheadline' , array(
            'section' => 'bawahheadline',
            'type'=>'textarea',
            'priority' => 3,
        ));


        // Iklan sebelum konten =========================================================== 
        $wp_customize3->add_section( 'beforecontent', array(
            'title' => __('Banner/Ads Before Content', 'kibaran'),
            'description'=> __('Enter your banner/ads code, size 970x90 px. For an example banner, you can enter this code:<br><b style="color: red;">&lt;img width=&quot;970&quot; height=&quot;90&quot; src=&quot;https://demo.pojoksoft.com/kibaran/wp-content/uploads/2024/01/1115647138008519075251.jpg&quot;&gt;</b><br><br>', 'kibaran'),
            'panel' => 'KibaranBanner',
        ));
        $wp_customize3->add_setting( 'adsbeforecontent' , array(
            'default'    => '',
            'transport'  =>  'refresh'
        ));
        $wp_customize3->add_control('adsbeforecontent' , array(
            'section' => 'beforecontent',
            'type'=>'textarea',
            'priority' => 3,
        ));


    // Dalam Post (Parallax) =========================================================== 
    $wp_customize3->add_section( 'dalampostparallax', array(
        'title' => __('Banner/Ads Inside Content (Parallax)', 'kibaran'),
        'description'=> __('Enter your banner/ads code, size 300x600 px. For an example banner, you can enter this code:<br><b style="color: red;">&lt;img width=&quot;300&quot; height=&quot;600&quot; src=&quot;https://demo.pojoksoft.com/kibaran/wp-content/uploads/2024/01/design4223.jpg&quot;&gt;</b><br><br>', 'kibaran'),
      'panel' => 'KibaranBanner',
      ));
    $wp_customize3->add_setting( 'adsdalampostparallax' , array(
      'default'    => '',
      'transport'  =>  'refresh'
    ));
    $wp_customize3->add_control('adsdalampostparallax' , array(
      'section' => 'dalampostparallax',
      'label' => __('Banner/Ads in Posts (Parallax)', 'kibaran'),
      'type'=>'textarea',
      'priority' => 3,
    ));
    $wp_customize3->add_setting( 'posisiadsdalampostparallax' , array(
      'default'    => '2',
      'transport'  =>  'refresh'
    ));
    $wp_customize3->add_control('posisiadsdalampostparallax' , array(
      'section' => 'dalampostparallax',
      'label' => __('Banner/Ads Position', 'kibaran'),
      'description'=> __('The position after the paragraph where the banner/ads is displayed', 'kibaran'),
      'type'=>'number',
        'input_attrs' => array(
          'min' =>1,
        ),
      'priority' => 3,
    ));
    $wp_customize3->add_setting( 'textparallax' , array(
      'default'    => '',
      'transport'  =>  'refresh'
    ));
    $wp_customize3->add_control('textparallax' , array(
      'section' => 'dalampostparallax',
      'label' => __('Text Above Parallax Box', 'kibaran'),
      'type'=>'text',
      'priority' => 3,
    ));
    $wp_customize3->add_setting( 'textparallaxbawah' , array(
      'default'    => '',
      'transport'  =>  'refresh'
    ));
    $wp_customize3->add_control('textparallaxbawah' , array(
      'section' => 'dalampostparallax',
      'label' => __('Text Below Parallax Box', 'kibaran'),
      'type'=>'text',
      'priority' => 3,
    ));

        // Bawah Tombol Share Post =========================================================== 
        $wp_customize3->add_section( 'bawahsharepost', array(
            'title' => __('Banner/Ads Below the Share Post Button', 'kibaran'),
            'description'=> __('Enter your banner/ads code, size 320x100 px. For an example banner, you can enter this code:<br><b style="color: red;">&lt;img width=&quot;320&quot; height=&quot;100&quot; src=&quot;https://demo.pojoksoft.com/kibaran/wp-content/uploads/2024/01/idt-size-400130.jpg&quot;&gt;</b><br><br>', 'kibaran'),
            'panel' => 'KibaranBanner',
        ));
        $wp_customize3->add_setting( 'adsbawahsharepost' , array(
            'default'    => '',
            'transport'  =>  'refresh'
        ));
        $wp_customize3->add_control('adsbawahsharepost' , array(
            'section' => 'bawahsharepost',
            'type'=>'textarea',
            'priority' => 3,
        ));

        // Sebelum Trending dalam Halaman Post =========================================================== 
        $wp_customize3->add_section( 'beforetrendingpost', array(
            'title' => __('Banner/Ads Before Trending Post in Post Page', 'kibaran'),
            'description'=> __('Enter your banner/ads code, size 970x90 px. For an example banner, you can enter this code:<br><b style="color: red;">&lt;img width=&quot;970&quot; height=&quot;90&quot; src=&quot;https://demo.pojoksoft.com/kibaran/wp-content/uploads/2024/01/132096228537643196.gif&quot;&gt;</b><br><br>', 'kibaran'),
            'panel' => 'KibaranBanner',
        ));
        $wp_customize3->add_setting( 'adsbeforetrendingpost' , array(
            'default'    => '',
            'transport'  =>  'refresh'
        ));
        $wp_customize3->add_control('adsbeforetrendingpost' , array(
            'section' => 'beforetrendingpost',
            'type'=>'textarea',
            'priority' => 3,
        ));

        // Float Kiri =========================================================== 
        $wp_customize3->add_section( 'floatkiri', array(
            'title' => __('Floating Left Banner/Ads', 'kibaran'),
            'description'=> __('Enter your banner/ads code, size 160x600 px. For an example banner, you can enter this code:<br><b style="color: red;">&lt;img width=&quot;160&quot; height=&quot;600&quot; src=&quot;https://demo.pojoksoft.com/kibaran/wp-content/uploads/2024/01/230313-ayla2-160x600-v2.jpg&quot;&gt;</b><br><br>', 'kibaran'),
            'panel' => 'KibaranBanner',
        ));
        $wp_customize3->add_setting( 'adsfloatkiri' , array(
            'default'    => '',
            'transport'  =>  'refresh'
        ));
        $wp_customize3->add_control('adsfloatkiri' , array(
            'section' => 'floatkiri',
            'type'=>'textarea',
            'priority' => 3,
        ));
        // Float Kanan =========================================================== 
        $wp_customize3->add_section( 'floatkanan', array(
            'title' => __('Floating Right Banner/Ads', 'kibaran'),
            'description'=> __('Enter your banner/ads code, size 160x600 px. For an example banner, you can enter this code:<br><b style="color: red;">&lt;img width=&quot;160&quot; height=&quot;600&quot; src=&quot;https://demo.pojoksoft.com/kibaran/wp-content/uploads/2024/01/230313-ayla2-160x600-v2.jpg&quot;&gt;</b><br><br>', 'kibaran'),
            'panel' => 'KibaranBanner',
        ));
        $wp_customize3->add_setting( 'adsfloatkanan' , array(
            'default'    => '',
            'transport'  =>  'refresh'
        ));
        $wp_customize3->add_control('adsfloatkanan' , array(
            'section' => 'floatkanan',
            'type'=>'textarea',
            'priority' => 3,
        ));

        // Float Footer Mobile =========================================================== 
        $wp_customize3->add_section( 'floatfootermobile', array(
            'title' => __('Floating Footer Banner/Ads (Mobile)', 'kibaran'),
            'description'=> __('Enter your banner/ads code, size 300x47 px. For an example banner, you can enter this code:<br><b style="color: red;">&lt;img width=&quot;300&quot; height=&quot;47&quot; src=&quot;https://demo.pojoksoft.com/kibaran/wp-content/uploads/2024/01/1612784256027194796-1.jpg&quot;&gt;</b><br><br>', 'kibaran'),
            'panel' => 'KibaranBanner',
        ));
        $wp_customize3->add_setting( 'adsfloatfootermobile' , array(
            'default'    => '',
            'transport'  =>  'refresh'
        ));
        $wp_customize3->add_control('adsfloatfootermobile' , array(
            'section' => 'floatfootermobile',
            'type'=>'textarea',
            'priority' => 3,
        ));

        // Diantara Post =========================================================== 
        $wp_customize3->add_section( 'betweenpost', array(
            'title' => __('Banner/Ads Between Posts', 'kibaran'),
            'description'=> __('<b>Note:</b> <b style="color: red;">for normal Homepage Type</b>. Enter your banner/ads code, size 468x60 px. For an example banner, you can enter this code:<br><b style="color: red;">&lt;img src=&quot;https://demo.pojoksoft.com/kibaran/wp-content/uploads/2024/01/idt-size-400130.jpg&quot;&gt;</b><br><br>', 'kibaran'),
            'panel' => 'KibaranBanner',
        ));
        $wp_customize3->add_setting( 'adsbetweenpost' , array(
            'default'    => '',
            'transport'  =>  'refresh'
        ));
        $wp_customize3->add_control('adsbetweenpost' , array(
            'section' => 'betweenpost',
            'label'   => __('1st Banner/Ads between posts', 'kibaran'),
            'type'=>'textarea',
            'priority' => 1,
        ));
        $wp_customize3->add_setting( 'adsbetweenpostposition' , array(
          'sanitize_callback' => 'wp_filter_nohtml_kses', //removes all HTML from content
          'type'          => 'theme_mod',
          'transport'     => 'refresh',
          'default'       => 'third',
        ) );


        // Create control Jumlah Pembaca
        $wp_customize3->add_control( 'adsbetweenpostposition', array(
          'label'      => __('1st Banner/Ads position is displayed', 'kibaran'),
          'section'    => 'betweenpost',
          'settings'   => 'adsbetweenpostposition',
          'priority'   => 2,
          'type'       => 'radio',
                'choices'    => array( 
                    'first'  => __('After the First Post', 'kibaran'),
                    'second' => __('After the Second Post', 'kibaran'),
                    'third'  => __('After the Third Post', 'kibaran'),
                    'fourth' => __('After the Fourth Post', 'kibaran'),
                    'five'   => __('After the Fifth Post', 'kibaran'),
                ),
        ) );
        $wp_customize3->add_setting( 'adsbetweenpost2' , array(
            'default'    => '',
            'transport'  =>  'refresh'
        ));
        $wp_customize3->add_control('adsbetweenpost2' , array(
            'section' => 'betweenpost',
            'label'   => __('2nd Banner/Ads between posts', 'kibaran'),
            'type'=>'textarea',
            'priority' => 3,
        ));
        $wp_customize3->add_setting( 'adsbetweenpostposition2' , array(
          'sanitize_callback' => 'wp_filter_nohtml_kses', //removes all HTML from content
          'type'          => 'theme_mod',
          'transport'     => 'refresh',
          'default'       => 'third',
        ) );


        // Create control Jumlah Pembaca
        $wp_customize3->add_control( 'adsbetweenpostposition2', array(
          'label'      => __('2nd Banner/Ads position is displayed', 'kibaran'),
          'section'    => 'betweenpost',
          'settings'   => 'adsbetweenpostposition2',
          'priority'   => 4,
          'type'       => 'radio',
                'choices'    => array( 
                    'first'  => __('After the First Post', 'kibaran'),
                    'second' => __('After the Second Post', 'kibaran'),
                    'third'  => __('After the Third Post', 'kibaran'),
                    'fourth' => __('After the Fourth Post', 'kibaran'),
                    'five'   => __('After the Fifth Post', 'kibaran'),
                ),
        ) );
        $wp_customize3->add_setting( 'adsbetweenpost3' , array(
            'default'    => '',
            'transport'  =>  'refresh'
        ));
        $wp_customize3->add_control('adsbetweenpost3' , array(
            'section' => 'betweenpost',
            'label'   => __('3rd Banner/Ads between posts', 'kibaran'),
            'type'=>'textarea',
            'priority' => 5,
        ));
        $wp_customize3->add_setting( 'adsbetweenpostposition3' , array(
          'sanitize_callback' => 'wp_filter_nohtml_kses', //removes all HTML from content
          'type'          => 'theme_mod',
          'transport'     => 'refresh',
          'default'       => 'third',
        ) );


        // Create control Jumlah Pembaca
        $wp_customize3->add_control( 'adsbetweenpostposition3', array(
          'label'      => __('3rd Banner/Ads position is displayed', 'kibaran'),
          'section'    => 'betweenpost',
          'settings'   => 'adsbetweenpostposition3',
          'priority'   => 6,
          'type'       => 'radio',
                'choices'    => array( 
                    'first'  => __('After the First Post', 'kibaran'),
                    'second' => __('After the Second Post', 'kibaran'),
                    'third'  => __('After the Third Post', 'kibaran'),
                    'fourth' => __('After the Fourth Post', 'kibaran'),
                    'five'   => __('After the Fifth Post', 'kibaran'),
                ),
        ) );
        // Bawah Block Kategori =========================================================== 
        $wp_customize3->add_section( 'bawahblock', array(
            'title' => __('Banner/Ads Under Category Block', 'kibaran'),
            'description'=> __('<b>Note:</b> <b style="color: red;">for Category Block Homepage Type</b>. Enter your banner/ads code, size 970x90 px. For an example banner, you can enter this code:<br><b style="color: red;">&lt;img width=&quot;970&quot; height=&quot;90&quot; src=&quot;https://demo.pojoksoft.com/kibaran/wp-content/uploads/2024/01/132096228537643196.gif&quot;&gt;</b><br><br>', 'kibaran'),
            'panel' => 'KibaranBanner',
        ));
        $wp_customize3->add_setting( 'bawahblock1' , array(
            'default'    => '',
            'transport'  =>  'refresh'
        ));
        $wp_customize3->add_control('bawahblock1' , array(
            'section' => 'bawahblock',
            'label'   => __('Banner/Ads below the block 1', 'kibaran'),
            'type'=>'textarea',
            'priority' => 3,
        ));
        $wp_customize3->add_setting( 'bawahblock2' , array(
            'default'    => '',
            'transport'  =>  'refresh'
        ));
        $wp_customize3->add_control('bawahblock2' , array(
            'section' => 'bawahblock',
            'label'   => __('Banner/Ads below the block 2', 'kibaran'),
            'type'=>'textarea',
            'priority' => 3,
        ));
        $wp_customize3->add_setting( 'bawahblock3' , array(
            'default'    => '',
            'transport'  =>  'refresh'
        ));
        $wp_customize3->add_control('bawahblock3' , array(
            'section' => 'bawahblock',
            'label'   => __('Banner/Ads below the block 3', 'kibaran'),
            'type'=>'textarea',
            'priority' => 3,
        ));
        $wp_customize3->add_setting( 'bawahblock4' , array(
            'default'    => '',
            'transport'  =>  'refresh'
        ));
        $wp_customize3->add_control('bawahblock4' , array(
            'section' => 'bawahblock',
            'label'   => __('Banner/Ads below the block 4', 'kibaran'),
            'type'=>'textarea',
            'priority' => 3,
        ));
        $wp_customize3->add_setting( 'bawahblock5' , array(
            'default'    => '',
            'transport'  =>  'refresh'
        ));
        $wp_customize3->add_control('bawahblock5' , array(
            'section' => 'bawahblock',
            'label'   => __('Banner/Ads below the block 5', 'kibaran'),
            'type'=>'textarea',
            'priority' => 3,
        ));
        $wp_customize3->add_setting( 'bawahblock6' , array(
            'default'    => '',
            'transport'  =>  'refresh'
        ));
        $wp_customize3->add_control('bawahblock6' , array(
            'section' => 'bawahblock',
            'label'   => __('Banner/Ads below the block 6', 'kibaran'),
            'type'=>'textarea',
            'priority' => 3,
        ));
        $wp_customize3->add_setting( 'bawahblock7' , array(
            'default'    => '',
            'transport'  =>  'refresh'
        ));
        $wp_customize3->add_control('bawahblock7' , array(
            'section' => 'bawahblock',
            'label'   => __('Banner/Ads below the block 7', 'kibaran'),
            'type'=>'textarea',
            'priority' => 3,
        ));
        $wp_customize3->add_setting( 'bawahblock8' , array(
            'default'    => '',
            'transport'  =>  'refresh'
        ));
        $wp_customize3->add_control('bawahblock8' , array(
            'section' => 'bawahblock',
            'label'   => __('Banner/Ads below the block 8', 'kibaran'),
            'type'=>'textarea',
            'priority' => 3,
        ));
        $wp_customize3->add_setting( 'bawahblock9' , array(
            'default'    => '',
            'transport'  =>  'refresh'
        ));
        $wp_customize3->add_control('bawahblock9' , array(
            'section' => 'bawahblock',
            'label'   => __('Banner/Ads below the block 9', 'kibaran'),
            'type'=>'textarea',
            'priority' => 3,
        ));
        $wp_customize3->add_setting( 'bawahblock10' , array(
            'default'    => '',
            'transport'  =>  'refresh'
        ));
        $wp_customize3->add_control('bawahblock10' , array(
            'section' => 'bawahblock',
            'label'   => __('Banner/Ads below the block 10', 'kibaran'),
            'type'=>'textarea',
            'priority' => 3,
        ));
        $wp_customize3->add_setting( 'bawahblock11' , array(
            'default'    => '',
            'transport'  =>  'refresh'
        ));
        $wp_customize3->add_control('bawahblock11' , array(
            'section' => 'bawahblock',
            'label'   => __('Banner/Ads below the block 11', 'kibaran'),
            'type'=>'textarea',
            'priority' => 3,
        ));
        $wp_customize3->add_setting( 'bawahblock12' , array(
            'default'    => '',
            'transport'  =>  'refresh'
        ));
        $wp_customize3->add_control('bawahblock12' , array(
            'section' => 'bawahblock',
            'label'   => __('Banner/Ads below the block 12', 'kibaran'),
            'type'=>'textarea',
            'priority' => 3,
        ));
        $wp_customize3->add_setting( 'bawahblock13' , array(
            'default'    => '',
            'transport'  =>  'refresh'
        ));
        $wp_customize3->add_control('bawahblock13' , array(
            'section' => 'bawahblock',
            'label'   => __('Banner/Ads below the block 13', 'kibaran'),
            'type'=>'textarea',
            'priority' => 3,
        ));
        $wp_customize3->add_setting( 'bawahblock14' , array(
            'default'    => '',
            'transport'  =>  'refresh'
        ));
        $wp_customize3->add_control('bawahblock14' , array(
            'section' => 'bawahblock',
            'label'   => __('Banner/Ads below the block 14', 'kibaran'),
            'type'=>'textarea',
            'priority' => 3,
        ));
        $wp_customize3->add_setting( 'bawahblock15' , array(
            'default'    => '',
            'transport'  =>  'refresh'
        ));
        $wp_customize3->add_control('bawahblock15' , array(
            'section' => 'bawahblock',
            'label'   => __('Banner/Ads below the block 15', 'kibaran'),
            'type'=>'textarea',
            'priority' => 3,
        ));
        $wp_customize3->add_setting( 'bawahblock16' , array(
            'default'    => '',
            'transport'  =>  'refresh'
        ));
        $wp_customize3->add_control('bawahblock16' , array(
            'section' => 'bawahblock',
            'label'   => __('Banner/Ads below the block 16', 'kibaran'),
            'type'=>'textarea',
            'priority' => 3,
        ));
        $wp_customize3->add_setting( 'bawahblock17' , array(
            'default'    => '',
            'transport'  =>  'refresh'
        ));
        $wp_customize3->add_control('bawahblock17' , array(
            'section' => 'bawahblock',
            'label'   => __('Banner/Ads below the block 17', 'kibaran'),
            'type'=>'textarea',
            'priority' => 3,
        ));
        $wp_customize3->add_setting( 'bawahblock18' , array(
            'default'    => '',
            'transport'  =>  'refresh'
        ));
        $wp_customize3->add_control('bawahblock18' , array(
            'section' => 'bawahblock',
            'label'   => __('Banner/Ads below the block 18', 'kibaran'),
            'type'=>'textarea',
            'priority' => 3,
        ));
        $wp_customize3->add_setting( 'bawahblock19' , array(
            'default'    => '',
            'transport'  =>  'refresh'
        ));
        $wp_customize3->add_control('bawahblock19' , array(
            'section' => 'bawahblock',
            'label'   => __('Banner/Ads below the block 19', 'kibaran'),
            'type'=>'textarea',
            'priority' => 3,
        ));
        $wp_customize3->add_setting( 'bawahblock20' , array(
            'default'    => '',
            'transport'  =>  'refresh'
        ));
        $wp_customize3->add_control('bawahblock20' , array(
            'section' => 'bawahblock',
            'label'   => __('Banner/Ads below the block 20', 'kibaran'),
            'type'=>'textarea',
            'priority' => 3,
        ));
        $wp_customize3->add_setting( 'bawahblock21' , array(
            'default'    => '',
            'transport'  =>  'refresh'
        ));
        $wp_customize3->add_control('bawahblock21' , array(
            'section' => 'bawahblock',
            'label'   => __('Banner/Ads below the block 21', 'kibaran'),
            'type'=>'textarea',
            'priority' => 3,
        ));
        $wp_customize3->add_setting( 'bawahblock22' , array(
            'default'    => '',
            'transport'  =>  'refresh'
        ));
        $wp_customize3->add_control('bawahblock22' , array(
            'section' => 'bawahblock',
            'label'   => __('Banner/Ads below the block 22', 'kibaran'),
            'type'=>'textarea',
            'priority' => 3,
        ));
        $wp_customize3->add_setting( 'bawahblock23' , array(
            'default'    => '',
            'transport'  =>  'refresh'
        ));
        $wp_customize3->add_control('bawahblock23' , array(
            'section' => 'bawahblock',
            'label'   => __('Banner/Ads below the block 23', 'kibaran'),
            'type'=>'textarea',
            'priority' => 3,
        ));
        $wp_customize3->add_setting( 'bawahblock24' , array(
            'default'    => '',
            'transport'  =>  'refresh'
        ));
        $wp_customize3->add_control('bawahblock24' , array(
            'section' => 'bawahblock',
            'label'   => __('Banner/Ads below the block 24', 'kibaran'),
            'type'=>'textarea',
            'priority' => 3,
        ));
        $wp_customize3->add_setting( 'bawahblock25' , array(
            'default'    => '',
            'transport'  =>  'refresh'
        ));
        $wp_customize3->add_control('bawahblock25' , array(
            'section' => 'bawahblock',
            'label'   => __('Banner/Ads below the block 25', 'kibaran'),
            'type'=>'textarea',
            'priority' => 3,
        ));
        $wp_customize3->add_setting( 'bawahblock26' , array(
            'default'    => '',
            'transport'  =>  'refresh'
        ));
        $wp_customize3->add_control('bawahblock26' , array(
            'section' => 'bawahblock',
            'label'   => __('Banner/Ads below the block 26', 'kibaran'),
            'type'=>'textarea',
            'priority' => 3,
        ));
        $wp_customize3->add_setting( 'bawahblock27' , array(
            'default'    => '',
            'transport'  =>  'refresh'
        ));
        $wp_customize3->add_control('bawahblock27' , array(
            'section' => 'bawahblock',
            'label'   => __('Banner/Ads below the block 27', 'kibaran'),
            'type'=>'textarea',
            'priority' => 3,
        ));
        $wp_customize3->add_setting( 'bawahblock28' , array(
            'default'    => '',
            'transport'  =>  'refresh'
        ));
        $wp_customize3->add_control('bawahblock28' , array(
            'section' => 'bawahblock',
            'label'   => __('Banner/Ads below the block 28', 'kibaran'),
            'type'=>'textarea',
            'priority' => 3,
        ));
        $wp_customize3->add_setting( 'bawahblock29' , array(
            'default'    => '',
            'transport'  =>  'refresh'
        ));
        $wp_customize3->add_control('bawahblock29' , array(
            'section' => 'bawahblock',
            'label'   => __('Banner/Ads below the block 29', 'kibaran'),
            'type'=>'textarea',
            'priority' => 3,
        ));
        $wp_customize3->add_setting( 'bawahblock30' , array(
            'default'    => '',
            'transport'  =>  'refresh'
        ));
        $wp_customize3->add_control('bawahblock30' , array(
            'section' => 'bawahblock',
            'label'   => __('Banner/Ads below the block 30', 'kibaran'),
            'type'=>'textarea',
            'priority' => 3,
        ));

}
  add_action( 'customize_register', 'addCustomize3' );

add_filter( 'color_utama', function() {
  if(!empty(get_theme_mod( 'color_utama' ))):
    return  get_theme_mod( 'color_utama' );
  else:
    return "#00a1b0";
  endif;
});

function my_customize_sanitize_footer_image($input)
{
    error_log(attachment_url_to_postid($input));//debug
    return attachment_url_to_postid($input);
}

/**
 * Returns a custom footer image set in the WordPress Customizer
 *
 * @see get_custom_logo()   based on core function for the custom logo
 *
 * @param int $blog_id Optional. ID of the blog in question. Default is the ID of the current blog.
 *
 * @return string Custom logo markup.
 */
function my_get_footer_image($blog_id = 0)
{
    $html = '';
    $switched_blog = false;

    if (is_multisite() && !empty($blog_id) && (int)$blog_id !== get_current_blog_id()) {
        switch_to_blog($blog_id);
        $switched_blog = true;
    }

    $custom_logo_id = get_theme_mod('footer_image');

    if ($custom_logo_id) {
        $custom_logo_attr = array(
            'class' => 'footer-image',
        );

        /*
         * If the image alt attribute is empty, get the site title and explicitly
         * pass it to the attributes used by wp_get_attachment_image().
         */
        $image_alt = get_post_meta($custom_logo_id, '_wp_attachment_image_alt', true);
        if (empty($image_alt)) {
            $custom_logo_attr['alt'] = get_bloginfo('name', 'display');
        }

        /*
         * If the alt attribute is not empty, there's no need to explicitly pass
         * it because wp_get_attachment_image() already adds the alt attribute.
         */
        $html = sprintf(
            '<div class="footer-image-wrap" rel="home">%2$s</div>',
            esc_url(home_url('/')),
            wp_get_attachment_image($custom_logo_id, 'full', false, $custom_logo_attr)
        );
    } elseif (is_customize_preview()) {
        // If no image is set but we're in the Customizer, leave a placeholder (needed for the live preview).
        $html = sprintf(
            '<div class="footer-image-wrap" style="display:none;"><img class="footer-image"/></div>',
            esc_url(home_url('/'))
        );
    }

    if ($switched_blog) {
        restore_current_blog();
    }

    /**
     * Filters the custom footer image output
     *
     * @param string $html    Custom footer image HTML output
     * @param int    $blog_id ID of the blog to get the custom footer image for
     */
    return apply_filters('my_get_footer_image', $html, $blog_id);
}

?>